#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "level.h"
#include "character.h"
#include "log.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();


private slots:
    void on_pushButton_clicked();               // 添加按钮

    void on_pushButton_2_clicked();             // 修改按钮

    void on_pushButton_5_clicked();             //清空按钮

    void on_pushButton_3_clicked();              // 查询按钮

    void on_pushButton_4_clicked();              // 删除按钮

    void on_pushButton_8_clicked();              // 显示内容

    void on_pushButton_10_clicked();             // 从excel导入

    void on_pushButton_11_clicked();             // 导出到excel

    void on_pushButton_6_clicked();              // 退出按钮

    void on_pushButton_12_clicked();             // 备份json文件

    void on_pushButton_13_clicked();

private:
    Ui::Widget *ui;
    Level level;
    QString strLog;
    Log mLog;

protected:
     void closeEvent(QCloseEvent *event);
     void dupJson();
     void dupJsonBeforeReadExcel();
     void loadImage(QString imagename);

};

#endif // WIDGET_H
