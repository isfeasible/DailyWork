#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>


QVector<Employee> SongGroup;

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->dateEdit->setDateTime(QDateTime::currentDateTime());
    ui->dateEdit_2->setDateTime(QDateTime::fromString("2016-07-25", "yyyy-MM-dd"));
}

Widget::~Widget()
{
    delete ui;
}

// 添加按钮
void Widget::on_pushButton_clicked()
{
    qDebug()<<"添加按钮";
    Employee firstOne;

    if(ui->lineEdit->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少姓名");
        return;
    }
    if(ui->lineEdit_3->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少身份证号");
        return;
    }
    if(ui->lineEdit_4->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少户口所在地");
        return;
    }
    if(ui->lineEdit_5->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少籍贯");
        return;
    }
    if(ui->lineEdit_6->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少联系电话");
        return;
    }
    if(ui->lineEdit_7->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少银行卡号");
        return;
    }
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少员工编号");
        return;
    }
    if(ui->lineEdit_10->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少工龄");
        return;
    }

    QString Person_ID = ui->lineEdit_3->text();
    QString YuanGongID = ui->lineEdit_8->text();
    for (int i = 0; i < SongGroup.size(); ++i) {
        if (SongGroup.at(i).Person_ID == Person_ID){
            QMessageBox::about(NULL, "错误", "身份证号重复");
            return;
        }
    }
    for (int i = 0; i < SongGroup.size(); ++i) {
        if (SongGroup.at(i).YuanGongID == YuanGongID){
            QMessageBox::about(NULL, "错误", "员工编号重复");
            return;
        }
    }


    firstOne.name = ui->lineEdit->text();
    firstOne.gender = ui->comboBox->currentText();
    firstOne.BirthDate = ui->dateEdit->dateTime().toString("yyyy-MM-dd");
    firstOne.Person_ID = ui->lineEdit_3->text();
    firstOne.Xueli = ui->comboBox_2->currentText();
    firstOne.Hukou = ui->lineEdit_4->text();
    firstOne.JiGuan = ui->lineEdit_5->text();
    firstOne.PhoneNumber = ui->lineEdit_6->text();
    firstOne.BankID = ui->lineEdit_7->text();

    firstOne.YuanGongID = ui->lineEdit_8->text();
    firstOne.Bumen = ui->comboBox_3->currentText();
    firstOne.Zhiwei = ui->comboBox_4->currentText();
    firstOne.GongLin = ui->lineEdit_10->text();
    firstOne.ZhuangTai = ui->comboBox_5->currentText();
    firstOne.Beizhu = ui->textEdit->toPlainText();

    SongGroup.append(firstOne);
    QMessageBox::about(NULL, "提示", "添加成功");
}

// 修改按钮
void Widget::on_pushButton_2_clicked()
{
    qDebug()<<"修改按钮";
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少修改用的员工编号");
        return;
    }
    bool if_existed = false;
    int index = 0;
    QString YuanGongID = ui->lineEdit_8->text();
    for (int i = 0; i < SongGroup.size(); ++i) {
        if (SongGroup.at(i).YuanGongID == YuanGongID){
            if_existed = true;
            index = i;
        }
    }
    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }else{

        if(ui->lineEdit->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少姓名");
            return;
        }
        if(ui->lineEdit_3->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少身份证号");
            return;
        }
        if(ui->lineEdit_4->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少户口所在地");
            return;
        }
        if(ui->lineEdit_5->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少籍贯");
            return;
        }
        if(ui->lineEdit_6->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少联系电话");
            return;
        }
        if(ui->lineEdit_7->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少银行卡号");
            return;
        }
        if(ui->lineEdit_10->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少工龄");
            return;
        }

        QString Person_ID = ui->lineEdit_3->text();
        for (int i = 0; i < SongGroup.size(); ++i) {
            if (SongGroup.at(i).Person_ID == Person_ID){
                QMessageBox::about(NULL, "错误", "身份证号重复");
                return;
            }
        }

        Employee secOne;
        secOne.name = ui->lineEdit->text();
        secOne.gender = ui->comboBox->currentText();
        secOne.BirthDate = ui->dateEdit->dateTime().toString("yyyy-MM-dd");
        secOne.Person_ID = ui->lineEdit_3->text();
        secOne.Xueli = ui->comboBox_2->currentText();
        secOne.Hukou = ui->lineEdit_4->text();
        secOne.JiGuan = ui->lineEdit_5->text();
        secOne.PhoneNumber = ui->lineEdit_6->text();
        secOne.BankID = ui->lineEdit_7->text();
        secOne.YuanGongID = ui->lineEdit_8->text();
        secOne.Bumen = ui->comboBox_3->currentText();
        secOne.Zhiwei = ui->comboBox_4->currentText();
        secOne.GongLin = ui->lineEdit_10->text();
        secOne.ZhuangTai = ui->comboBox_5->currentText();
        secOne.Beizhu = ui->textEdit->toPlainText();

        SongGroup.remove(index);
        SongGroup.insert(index, secOne);

        QMessageBox::about(NULL, "提示", "修改成功");
    }

}

// 查询按钮
void Widget::on_pushButton_3_clicked()
{
    qDebug()<<"查询按钮";
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少查询用的员工编号");
        return;
    }
    bool if_existed = false;
    QString YuanGongID = ui->lineEdit_8->text();
    for (int i = 0; i < SongGroup.size(); ++i) {
        if (SongGroup.at(i).YuanGongID == YuanGongID){
            if_existed = true;
            ui->lineEdit->setText(SongGroup.at(i).name);
            ui->comboBox->setCurrentText(SongGroup.at(i).gender);
            QString strBuffer = SongGroup.at(i).BirthDate;
            ui->dateEdit->setDateTime(QDateTime::fromString(strBuffer, "yyyy-MM-dd"));
            ui->lineEdit_3->setText(SongGroup.at(i).Person_ID);
            ui->comboBox_2->setCurrentText(SongGroup.at(i).Xueli);
            ui->lineEdit_4->setText(SongGroup.at(i).Hukou);
            ui->lineEdit_5->setText(SongGroup.at(i).JiGuan);
            ui->lineEdit_6->setText(SongGroup.at(i).PhoneNumber);
            ui->lineEdit_7->setText(SongGroup.at(i).BankID);
            ui->lineEdit_8->setText(SongGroup.at(i).YuanGongID);
            ui->comboBox_3->setCurrentText(SongGroup.at(i).Bumen);
            ui->comboBox_4->setCurrentText(SongGroup.at(i).Zhiwei);
            ui->lineEdit_10->setText(SongGroup.at(i).GongLin);
            ui->comboBox_5->setCurrentText(SongGroup.at(i).ZhuangTai);
            ui->textEdit->setPlainText(SongGroup.at(i).Beizhu);
        }
    }
    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }

    QMessageBox::about(NULL, "提示", "查询成功");
}

// 删除按钮
void Widget::on_pushButton_4_clicked()
{
    qDebug()<<"删除按钮";
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少删除用的员工编号");
        return;
    }
    bool if_existed = false;
    int index = 0;
    QString YuanGongID = ui->lineEdit_8->text();
    for (int i = 0; i < SongGroup.size(); ++i) {
        if (SongGroup.at(i).YuanGongID == YuanGongID){
            if_existed = true;
            index = i;
        }
    }
    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }else{
        SongGroup.remove(index);
        QMessageBox::about(NULL, "提示", "删除成功");
    }
}

//清空按钮
void Widget::on_pushButton_5_clicked()
{
    qDebug()<<"清空按钮";
    ui->lineEdit->setText("");
    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");
    ui->lineEdit_5->setText("");
    ui->lineEdit_6->setText("");
    ui->lineEdit_7->setText("");
    ui->lineEdit_8->setText("");
    ui->lineEdit_10->setText("");
    ui->textEdit->setPlainText("");
    QMessageBox::about(NULL, "提示", "清空成功");
}



// 调试按钮
void Widget::on_pushButton_7_clicked()
{
    qDebug()<<"调试按钮";
    //qDebug()<<ui->comboBox->currentIndex();

    //QString gender = QString("\347\224\267");
    //qDebug()<<gender;
    /*if (gender == QString("\347\224\267")){
        //ui->comboBox->setCurrentIndex(0);
        //qDebug()<<ui->comboBox->currentIndex();
        ui->comboBox->setCurrentText(ui->comboBox->currentText());
        qDebug()<<"update date";
    /*}else if (gender == QStringLiteral("女")){
        ui->comboBox->setCurrentIndex(1);
        qDebug()<<ui->comboBox->currentIndex();
    }else{
        QMessageBox::about(NULL, QStringLiteral("错误"), QStringLiteral("性别栏信息错误"));
        qDebug()<<ui->comboBox->currentIndex();
    }*/

    //QString strBuffer = ui->dateEdit->dateTime().toString("yyyy-MM-dd");
    //qDebug()<< strBuffer;
    /*QDateTime time;

    strBuffer = "2010-07-02 17:35:00";

    time = QDateTime::fromString(strBuffer, "yyyy-MM-dd hh:mm:ss");*/


    //qDebug()<< strBuffer;
    qDebug()<<SongGroup.size();
    for (int i = 0; i < SongGroup.size(); ++i) {
        qDebug()<<SongGroup.at(i).name<<"  "<<SongGroup.at(i).YuanGongID;
    }
    QString YuanGongID = ui->lineEdit_8->text();
    for (int i = 0; i < SongGroup.size(); ++i) {
        if (SongGroup.at(i).YuanGongID == YuanGongID){
            qDebug()<<"find it";
            SongGroup.remove(i);
        }
    }
    qDebug()<<SongGroup.size();
    for (int i = 0; i < SongGroup.size(); ++i) {
        qDebug()<<SongGroup.at(i).name<<"  "<<SongGroup.at(i).YuanGongID;
    }
}

