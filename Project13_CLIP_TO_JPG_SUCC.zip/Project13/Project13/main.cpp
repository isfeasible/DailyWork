#include <windows.h>
#include <Wincodec.h>
#include <stdio.h>
#include <assert.h>

#define ERRORCHECK(hr) assert(SUCCEEDED(hr))
#define INPUTFORMAT    GUID_ContainerFormatBmp
#define OUTFORMAT      GUID_ContainerFormatJpeg


#pragma comment(lib, "Windowscodecs.lib" )

HRESULT PNG2WDP(WCHAR* szWdpFileName)
{
	IWICImagingFactory *piFactory = NULL;

	IWICBitmapEncoder *piEncoder = NULL;

	IWICBitmapFrameEncode *piBitmapFrame = NULL;

	IWICStream *piStream = NULL;

	UINT uiWidth = 0;
	UINT uiHeight = 0;

	ULONG counter = 0;

	CoInitialize(NULL);

	HRESULT hr = CoCreateInstance(
		CLSID_WICImagingFactory,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_IWICImagingFactory,
		(LPVOID*)&piFactory);

	/****************************************************************************************/
	::OpenClipboard(0);
	HANDLE hBitmap = ::GetClipboardData(CF_BITMAP);

	if (hBitmap == NULL){
		return 0;
	}
	HANDLE hPal = NULL;
	hPal = GetStockObject(DEFAULT_PALETTE);
	/***************************************************************************************/

	hr = piFactory->CreateStream(&piStream);
	ERRORCHECK(hr);
	
	hr = piStream->InitializeFromFilename(szWdpFileName, GENERIC_WRITE);
	ERRORCHECK(hr);

	hr = piFactory->CreateEncoder(OUTFORMAT, NULL, &piEncoder);
	ERRORCHECK(hr);

	hr = piEncoder->Initialize(piStream, WICBitmapEncoderNoCache);
	ERRORCHECK(hr);
	
	hr = piEncoder->CreateNewFrame(&piBitmapFrame, NULL);
	ERRORCHECK(hr);
	
	hr = piBitmapFrame->Initialize(NULL);
	ERRORCHECK(hr);

	IWICBitmap *pIBitmap = NULL;
	//hr = piFactory->CreateBitmapFromHBITMAP((HBITMAP)hBitmap, (HPALETTE)hPal, WICBitmapUseAlpha, &pIBitmap);
	hr = piFactory->CreateBitmapFromHBITMAP((HBITMAP)hBitmap, NULL, WICBitmapUseAlpha, &pIBitmap);
	ERRORCHECK(hr);

	pIBitmap->GetSize(&uiWidth, &uiHeight);

	hr = piBitmapFrame->SetSize(uiWidth, uiHeight);
	ERRORCHECK(hr);

	WICRect rcLock = { 0, 0, uiWidth, uiHeight };

	WICPixelFormatGUID formatGUID = GUID_WICPixelFormat32bppBGRA;
	hr = piBitmapFrame->SetPixelFormat(&formatGUID);
	ERRORCHECK(hr);

	hr = piBitmapFrame->WriteSource(pIBitmap, &rcLock);
	ERRORCHECK(hr);
	
	hr = piBitmapFrame->Commit();
	ERRORCHECK(hr);

	hr = piEncoder->Commit();
	ERRORCHECK(hr);

	if (pIBitmap){
		pIBitmap->Release();
	}

	if (piFactory){
		counter = piFactory->Release();
	}
		
	if (piBitmapFrame){
		counter = piBitmapFrame->Release();
	}
		
	if (piEncoder){
		counter = piEncoder->Release();
	}

	if (piStream){
		counter = piStream->Release();
	}

	::CloseClipboard();

	CoUninitialize();
	printf("little end\n");
	return hr;
}


int main(){
	printf("0\n");
	WCHAR* szWdpFileName = L"D:\\clipnext2.jpg";

	PNG2WDP(szWdpFileName);

	printf("end\n");
	system("pause");
	
	return 0;
}