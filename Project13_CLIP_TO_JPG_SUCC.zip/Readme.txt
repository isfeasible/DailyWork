hr = piFactory->CreateBitmapFromHBITMAP((HBITMAP)hBitmap, NULL, WICBitmapUseAlpha, &pIBitmap);
HPALETTE Ϊ NULL ����