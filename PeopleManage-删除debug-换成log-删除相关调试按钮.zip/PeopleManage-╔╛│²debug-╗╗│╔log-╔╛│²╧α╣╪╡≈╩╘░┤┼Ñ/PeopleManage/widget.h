#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "level.h"
#include "character.h"

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();


private slots:
    void on_pushButton_clicked();               // 添加按钮

    void on_pushButton_2_clicked();             // 修改按钮

    void on_pushButton_5_clicked();             //清空按钮

    void on_pushButton_3_clicked();              // 查询按钮

    void on_pushButton_7_clicked();              // 调试按钮

    void on_pushButton_4_clicked();              // 删除按钮

    void on_pushButton_8_clicked();              // 显示内容

    void on_pushButton_9_clicked();              // 生成数据库

    void on_pushButton_10_clicked();             // 从excel导入

    void on_pushButton_11_clicked();             // 导出到excel

    void log(const char *name, const char *info);

    void on_pushButton_12_clicked();             //  日志

private:
    Ui::Widget *ui;
    Level level;
    QString strLog;

protected:
     void closeEvent(QCloseEvent *event);

};

#endif // WIDGET_H
