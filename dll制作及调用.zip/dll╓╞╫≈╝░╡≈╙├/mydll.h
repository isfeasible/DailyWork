#pragma once

extern "C" _declspec(dllexport) int add(int a, int b);