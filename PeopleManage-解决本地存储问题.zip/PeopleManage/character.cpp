/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "character.h"

Character::Character() :
    _name(""),
    _gender(""),
    _BirthDate(""),
    _Person_ID(""),
    _Xueli(""),
    _Hukou(""),
    _JiGuan(""),
    _PhoneNumber(""),
    _BankID(""),
    _YuanGongID(""),
    _Bumen(""),
    _Zhiwei(""),
    _RuzhiDate(""),
    _GongLin(""),
    _ZhuangTai(""),
    _Beizhu("")
{
}

Character::Character(QString name,
          QString gender,
          QString BirthDate,
          QString Person_ID,
          QString Xueli,
          QString Hukou,
          QString JiGuan,
          QString PhoneNumber,
          QString BankID,
          QString YuanGongID,
          QString Bumen,
          QString Zhiwei,
          QString RuzhiDate,
          QString GongLin,
          QString ZhuangTai,
          QString Beizhu) :
          _name(name),
          _gender(gender),
          _BirthDate(BirthDate),
          _Person_ID(Person_ID),
          _Xueli(Xueli),
          _Hukou(Hukou),
          _JiGuan(JiGuan),
          _PhoneNumber(PhoneNumber),
          _BankID(BankID),
          _YuanGongID(YuanGongID),
          _Bumen(Bumen),
          _Zhiwei(Zhiwei),
          _RuzhiDate(RuzhiDate),
          _GongLin(GongLin),
          _ZhuangTai(ZhuangTai),
          _Beizhu(Beizhu)
{
}


QString Character::name() const
{
    return _name;
}

void Character::setName(QString name)
{
    _name = name;
}

QString Character::gender() const {
    return _gender;
}
void Character::setGender(QString gender) {
    _gender = gender;
}

QString Character::BirthDate() const {
    return _BirthDate;
}
void Character::setBirthDate(QString BirthDate) {
    _BirthDate = BirthDate;
}

QString Character::Person_ID() const {
    return _Person_ID;
}
void Character::setPerson_ID(QString Person_ID) {
    _Person_ID = Person_ID;
}

QString Character::Xueli() const {
    return _Xueli;
}
void Character::setXueli(QString Xueli) {
    _Xueli = Xueli;
}

QString Character::Hukou() const {
    return _Hukou;
}
void Character::setHukou(QString Hukou) {
    _Hukou = Hukou;
}

QString Character::JiGuan() const {
    return _JiGuan;
}
void Character::setJiGuan(QString JiGuan) {
    _JiGuan = JiGuan;
}

QString Character::PhoneNumber() const {
    return _PhoneNumber;
}
void Character::setPhoneNumber(QString PhoneNumber) {
    _PhoneNumber = PhoneNumber;
}

QString Character::BankID() const {
    return _BankID;
}
void Character::setBankID(QString BankID) {
    _BankID = BankID;
}

QString Character::YuanGongID() const {
    return _YuanGongID;
}
void Character::setYuanGongID(QString YuanGongID) {
    _YuanGongID = YuanGongID;
}

QString Character::Bumen() const {
    return _Bumen;
}
void Character::setBumen(QString Bumen) {
    _Bumen = Bumen;
}

QString Character::Zhiwei() const {
    return _Zhiwei;
}
void Character::setZhiwei(QString Zhiwei) {
    _Zhiwei = Zhiwei;
}

QString Character::RuzhiDate() const {
    return _RuzhiDate;
}
void Character::setRuzhiDate(QString RuzhiDate) {
    _RuzhiDate = RuzhiDate;
}

QString Character::GongLin() const {
    return _GongLin;
}
void Character::setGongLin(QString GongLin) {
    _GongLin = GongLin;
}

QString Character::ZhuangTai() const {
    return _ZhuangTai;
}
void Character::setZhuangTai(QString ZhuangTai){
    _ZhuangTai = ZhuangTai;
}

QString Character::Beizhu() const {
    return _Beizhu;
}
void Character::setBeizhu(QString Beizhu) {
    _Beizhu = Beizhu;
}


//! [0]
void Character::read(const QJsonObject &json)
{
    _name = json["name"].toString();
    _gender = json["gender"].toString();
    _BirthDate = json["BirthDate"].toString();
    _Person_ID = json["Person_ID"].toString();
    _Xueli = json["Xueli"].toString();
    _Hukou = json["Hukou"].toString();
    _JiGuan = json["JiGuan"].toString();
    _PhoneNumber = json["PhoneNumber"].toString();
    _BankID = json["BankID"].toString();
    _YuanGongID = json["YuanGongID"].toString();
    _Bumen = json["Bumen"].toString();
    _Zhiwei = json["Zhiwei"].toString();
    _RuzhiDate = json["RuzhiDate"].toString();
    _GongLin = json["GongLin"].toString();
    _ZhuangTai = json["ZhuangTai"].toString();
    _Beizhu = json["Beizhu"].toString();
}
//! [0]

//! [1]
void Character::write(QJsonObject &json) const
{
    json["name"] = _name;
    json["gender"] = _gender;
    json["BirthDate"] = _BirthDate;
    json["Person_ID"] = _Person_ID;
    json["Xueli"] = _Xueli;
    json["Hukou"] = _Hukou;
    json["JiGuan"] = _JiGuan;
    json["PhoneNumber"] = _PhoneNumber;
    json["BankID"] = _BankID;
    json["YuanGongID"] = _YuanGongID;
    json["Bumen"] = _Bumen;
    json["Zhiwei"] = _Zhiwei;
    json["RuzhiDate"] = _RuzhiDate;
    json["GongLin"] = _GongLin;
    json["ZhuangTai"] = _ZhuangTai;
    json["Beizhu"] = _Beizhu;
}
//! [1]
