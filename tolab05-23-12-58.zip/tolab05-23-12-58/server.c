
#include <stdio.h>
#include <winsock2.h>

#pragma comment(lib, "ws2_32.lib");

#define HTTP_DEF_PORT      4000     /* ���ӵ�ȱʡ�˿� */
#define HTTP_BUF_SIZE      1024     /* �������Ĵ�С */
#define HTTP_FILENAME_LEN   256     /* �ļ������� */

struct doc_type{

	char *suffix;
	char *type;
};

struct doc_type file_type[] = {
	{ "html", "text/html" },
	{ "gif", "image/gif" },
	{ "jpeg", "image/jpeg" },
	{ NULL, NULL }
};

char *http_res_hdr_tmpl = "HTTP/1.1 200 OK\r\nServer: Huiyong's Server <0.1>\r\n"
"Accept-Ranges: bytes\r\nContent-Length: %d\r\nConnection: close\r\n"
"Content-Type: %s\r\n\r\n";

char *http_get_type_by_suffix(const	char *suffix){
	struct doc_type *type;

	for (type = file_type; type->suffix; type++){
		if (strcmp(type->suffix, suffix) == 0){
			return type->type;
		}
	}
	return NULL;
}

/***************************
* ���������У��õ��ļ��������׺�������и�ʽ��
* [Get http://www.baidu.com:8080/index.html HTTP/1.1]
* ����˵����
* [IN] buf, �ַ�������
* [IN] buflen, buf����
* [OUT] file_name, �ļ���
* [OUT] suffix,��׺��
*
* **************************/

void http_parse_request_cmd(char *buf, int buflen, char *file_name, char *suffix){


	int length = 0;
	char *begin, *end, *bias;

	begin = strchr(buf, ' ');
	begin = begin + 1;

	end = strchr(begin, ' ');
	*end = 0;

	bias = strrchr(buf, '/');
	if (bias == NULL){
		bias = strchr(buf, '\\');
		if (bias == NULL){
			printf("[Web] invalid without \'/\' or \'\\\\\'\n");
			system("pause");
			exit(0);
		}
	}
	bias = bias + 1;
	length = end - bias;

	if (length > 0){
		memcpy(file_name, bias, length);
		file_name[length] = 0;

		begin = strchr(file_name, '.');
		if (begin){
			strcpy(suffix, begin + 1);
		}
	}
}


/***************************
* ��ͻ�����HTTP��Ӧ[Get http://www.baidu.com:8080/index.html HTTP/1.1]
*
* ����˵����
* [IN] buf, �ַ�������
* [IN] buflen, buf����
*
* ����ֵ���ɹ����ط�0��ʧ�ܷ���0
*
* **************************/

int http_send_response(SOCKET soc, char *buf, int buf_len){
	int read_len, file_len, hdr_len, send_len;

	char *type;
	char read_buf[HTTP_BUF_SIZE];
	char http_header[HTTP_BUF_SIZE];
	char file_name[HTTP_FILENAME_LEN] = "index.html", suffix[16] = "html";
	FILE *res_file;

	/* �õ���׺�� */
	http_parse_request_cmd(buf, buf_len, file_name, suffix);

	res_file = fopen(file_name, "rb+");
	if (res_file == NULL){
		printf("[Web] the file [%s] is not exist\n", file_name);
		return 0;
	}

	fseek(res_file, 0, SEEK_END);   // ���ļ�ĩβΪ��׼���ƶ�0���ֽ�
	file_len = ftell(res_file);     // ������ļ���С
	fseek(res_file, 0, SEEK_SET);

	type = http_get_type_by_suffix(suffix);
	if (type == NULL){
		printf("[Web] There is not the related content type\n");
		system("pause");
		return 0;
	}

	hdr_len = sprintf(http_header, http_res_hdr_tmpl, file_len, type);
	send_len = send(soc, http_header, hdr_len, 0);
	//printf("my send error:%d\n", send_len);

	if (send_len == SOCKET_ERROR){
		fclose(res_file);
		printf("[Web] Fail to send, error = %d\n", WSAGetLastError());
		system("pause");
		return 0;
	}

	do{
		read_len = fread(read_buf, sizeof(char), HTTP_BUF_SIZE, res_file);

		if (read_len > 0){
			send_len = send(soc, read_buf, read_len, 0);
			file_len -= read_len;
		}
	} while ((read_len > 0) && (file_len > 0));

	fclose(res_file);
	return 1;

}

int main(int argc, char**argv){
	WSADATA wsa_data;
	SOCKET srv_soc = 0, acpt_soc;
	struct sockaddr_in serv_addr;
	struct sockaddr_in from_addr;

	char recv_buf[HTTP_BUF_SIZE];
	unsigned short port = HTTP_DEF_PORT;

	int from_len = sizeof(from_addr);
	int result = 0, recv_len;

	if (argc == 2){
		port = atoi(argv[1]);
	}

	WSAStartup(MAKEWORD(2, 0), &wsa_data);

	srv_soc = socket(AF_INET, SOCK_STREAM, 0);

	if (srv_soc == INVALID_SOCKET){
		printf("[Web] socket() Fails, error =%d\n", WSAGetLastError());
		system("pause");
		return -1;
	}

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(port);
	char *cus_host = "127.0.0.1";
	unsigned long cus_addr = inet_addr(cus_host);
	//serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);   // INADDR_ANY, ������ĳһ�˿��ϵ������������շ�����
	serv_addr.sin_addr.s_addr = cus_addr;

	result = bind(srv_soc, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
	if (result == SOCKET_ERROR){
		closesocket(srv_soc);
		printf("[Web] Failed to bind, error = %d\n", WSAGetLastError());
		system("pause");
		return -1;
	}

	result = listen(srv_soc, SOMAXCONN);
	printf("The server is runnig at %d...\n", port);

	while (1){
		acpt_soc = accept(srv_soc, (struct sockaddr *)&from_addr, &from_len);
		if (acpt_soc == INVALID_SOCKET){
			printf("[Web] Failed to accept, error = %d\n", WSAGetLastError());
			system("pause");
			break;
		}

		printf("[Web] Accept address: [%s], port:[%d]\n", inet_ntoa(from_addr.sin_addr), ntohs(from_addr.sin_port));

		recv_len = recv(acpt_soc, recv_buf, HTTP_BUF_SIZE, 0);
		if (recv_len == SOCKET_ERROR){
			closesocket(acpt_soc);
			printf("[Web] Fail to recv, error = %d\n", WSAGetLastError());
			system("pause");
			break;
		}
		recv_buf[recv_len] = 0;
		printf("recv_buf:%s\n", recv_buf);

		result = http_send_response(acpt_soc, recv_buf, recv_len);
		closesocket(acpt_soc);
		printf("client is closed\n");
	}

	closesocket(srv_soc);
	WSACleanup();
	printf("[Web] The server is stopped.\n");

	return 0;
}