#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <WinSock2.h>

#pragma comment(lib, "ws2_32.lib")  /* WinSockʹ�õĿ⺯�� */

/* ���峣�� */
#define HTTP_DEF_PORT   4000  /* ���ӵ�ȱʡ�˿� */
#define HTTP_BUF_SIZE   1024  /* �������Ĵ�С   */
#define HTTP_HOST_LEN    256  /* ���������� */

char *http_req_hdr_tmpl = "GET %s HTTP/1.1\r\n"
"Accept: image/gif, image/jpeg, */*\r\nAccept-Language: zh-cn\r\n"
"Accept-Encoding: gzip, deflate\r\nHost: %s:%d\r\n"
"User-Agent: Huiyong's Browser <0.1>\r\nConnection: Keep-Alive\r\n\r\n";

/********************************
* [IN]: buf
* [OUT]: host
* [OUT]: port
* [OUT]: file_name
* ******************************/

void parse_url(const char *buf, char *host,
	unsigned short *port, char *file_name)
{
	char *begin, *colon, *host_end, *buf_end;
	int length;
	char s_port[8];

	buf_end = const_cast<char *>(buf + strlen(buf));

	begin = const_cast<char *>(strstr(buf, "//"));
	begin = begin ? begin + 2 : const_cast<char*>(buf);

	colon = strchr(begin, ':');
	host_end = strchr(begin, '/');

	if (host_end == NULL){
		host_end = buf_end;
	}
	else {
		host_end++;
		if (host_end != buf_end){
			strcpy(file_name, host_end);
		}
		host_end--;
	}

	if (colon){
		colon++;
		length = host_end - colon;
		memcpy(s_port, colon, length);
		s_port[length] = 0;
		*port = atoi(s_port);
		colon--;
	}

	length = colon - begin;
	memcpy(host, begin, length);
	host[length] = 0;
}

int main(int argc, char**argv){

	//char *debug_url = "http://127.0.0.1:8080:/index.html";

	WSADATA wsa_data;
	SOCKET http_sock = 0;
	struct sockaddr_in serv_addr;
	struct hostent *host_ent;

	int result = 0, send_len;
	char data_buf[HTTP_BUF_SIZE];
	char host[HTTP_HOST_LEN] = "127.0.0.1";
	unsigned short port = HTTP_DEF_PORT;
	unsigned long addr;

	char file_name[HTTP_HOST_LEN] = "index.html";
	char file_nameforsave[HTTP_HOST_LEN] = "index1.txt";

	FILE *file_web;

	if (argc != 2){
		printf("[Web] input : %s http://www.test.com[:8080]/index.html", argv[0]);
		system("pause");
		return -1;
	}

	printf("argv[1]: %s", argv[1]);
	parse_url(argv[1], host, &port, file_name);

	int i = 9;
	WSAStartup(MAKEWORD(2, 0), &wsa_data);

	addr = inet_addr(host);
	if (addr == INADDR_NONE){
		host_ent = gethostbyname(host);
		if (!host_ent){
			printf("[Web] invalid host\n");
			return -1;
		}

		memcpy(&addr, host_ent->h_addr_list[0], host_ent->h_length);
	}

	serv_addr.sin_family = AF_INET;    // Э��أ� AF_INET ��ʾTCP/IPЭ��
	serv_addr.sin_port = htons(port);  // htons �����ֽ���ת���������ֽ���
	serv_addr.sin_addr.s_addr = addr;

	http_sock = socket(AF_INET, SOCK_STREAM, 0);
	result = connect(http_sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr));

	if (result == SOCKET_ERROR){
		closesocket(http_sock);
		printf("[Web] fail to connect, error = %d\n", WSAGetLastError());
		system("pause");
		result - 1;
	}

	send_len = sprintf(data_buf, http_req_hdr_tmpl, argv[1], host, port);
	result = send(http_sock, data_buf, send_len, 0);
	if (result == SOCKET_ERROR){
		printf("[Web] fail to send, error = %d\n", WSAGetLastError());
		system("pause");
		return -1;
	}

	file_web = fopen(file_nameforsave, "ab");

	do{
		result = recv(http_sock, data_buf, HTTP_BUF_SIZE, 0);
		if (result > 0){

			/*data_buf[result - 1] = 0;
			printf("%s", data_buf);*/

			fwrite(data_buf, 1, result, file_web);

		}
	} while (result > 0);

	printf("Client finished\n");
	

	fclose(file_web);
	closesocket(http_sock);
	WSACleanup();

	system("pause");

	return 0;
}
