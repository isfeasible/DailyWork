#include <windows.h>
#include <Wincodec.h>
#include <iostream>
#include <fstream>  

#pragma comment(lib, "Windowscodecs.lib" )

HRESULT PNG2WDP(WCHAR* szPngFileName, WCHAR* szWdpFileName)
{
	IWICImagingFactory *piFactory = NULL;

	IWICBitmapEncoder *piEncoder = NULL;
	IWICBitmapDecoder *piDecoder = NULL;

	IWICBitmapFrameEncode *piBitmapFrame = NULL;
	IWICBitmapFrameDecode *piBitmapFrameIn = NULL;

	IPropertyBag2 *pPropertybag = NULL;

	IWICStream *piStream = NULL;
	IWICStream *piStreamIn = NULL;

	UINT uiWidth = 0;
	UINT uiHeight = 0;

	ULONG counter = 0;

	CoInitialize(NULL);

	HRESULT hr = CoCreateInstance(
		CLSID_WICImagingFactory,
		NULL,
		CLSCTX_INPROC_SERVER,
		IID_IWICImagingFactory,
		(LPVOID*)&piFactory);

	if (SUCCEEDED(hr))
	{
		hr = piFactory->CreateStream(&piStream);
	}

	if (SUCCEEDED(hr))
	{
		hr = piStream->InitializeFromFilename(szWdpFileName, GENERIC_WRITE);
	}

	if (SUCCEEDED(hr))
	{
		hr = piFactory->CreateStream(&piStreamIn);
	}

	if (SUCCEEDED(hr))
	{
		hr = piStreamIn->InitializeFromFilename(szPngFileName, GENERIC_READ);
	}

	if (SUCCEEDED(hr))
	{
		//hr = piFactory->CreateEncoder(GUID_ContainerFormatWmp, NULL, &piEncoder);
		hr = piFactory->CreateEncoder(GUID_ContainerFormatJpeg, NULL, &piEncoder);
	}

	if (SUCCEEDED(hr))
	{
		hr = piEncoder->Initialize(piStream, WICBitmapEncoderNoCache);
	}
	
	if (SUCCEEDED(hr))
	{
		hr = piEncoder->CreateNewFrame(&piBitmapFrame, &pPropertybag);
	}

	if (SUCCEEDED(hr))
	{
		hr = piFactory->CreateDecoder(GUID_ContainerFormatBmp, NULL, &piDecoder);
	}

	if (SUCCEEDED(hr))
	{
		hr = piDecoder->Initialize(piStreamIn, WICDecodeMetadataCacheOnDemand);
	}

	if (SUCCEEDED(hr))
	{
		hr = piDecoder->GetFrame(0, &piBitmapFrameIn);
	}

	if (SUCCEEDED(hr))
	{
		// This is how you customize the TIFF output.
		PROPBAG2 option = { 0 };
		//option.pstrName = L"TiffCompressionMethod";
		//VARIANT varValue;    
		//VariantInit(&varValue);
		//varValue.vt = VT_UI1;
		//varValue.bVal = WICTiffCompressionZIP;      
		//hr = pPropertybag->Write(1, &option, &varValue);        
		if (SUCCEEDED(hr))
		{
			hr = piBitmapFrame->Initialize(pPropertybag);
			printf("Im here\n");
		}
	}

	if (SUCCEEDED(hr))
	{
		hr = piBitmapFrameIn->GetSize(&uiWidth, &uiHeight);
		hr = piBitmapFrame->SetSize(uiWidth, uiHeight);
	}

	WICPixelFormatGUID formatGUID = GUID_WICPixelFormat32bppBGRA;
	hr = piBitmapFrame->SetPixelFormat(&formatGUID);
	printf("hr2��%d\n", hr);

	/*if (SUCCEEDED(hr))
	{
		hr = piBitmapFrameIn->GetPixelFormat(&formatGUID);
		hr = piBitmapFrame->SetPixelFormat(&formatGUID);
	}

	if (SUCCEEDED(hr))
	{
		// We're expecting to write out 24bppRGB. Fail if the encoder cannot do it.
		hr = IsEqualGUID(formatGUID, GUID_WICPixelFormat32bppBGRA) ? S_OK : E_FAIL;
		if (FAILED(hr))
		{
			hr = IsEqualGUID(formatGUID, GUID_WICPixelFormat24bppBGR) ? S_OK : E_FAIL;
		}
		
	}*/

	if (SUCCEEDED(hr))
	{
		{
			IWICBitmap *pIBitmap = NULL;
			IWICBitmapLock *pILock = NULL;

			WICRect rcLock = { 0, 0, uiWidth, uiHeight };

			// Create the bitmap from the image frame.
			if (SUCCEEDED(hr))
			{
				hr = piFactory->CreateBitmapFromSource(
					piBitmapFrameIn,          // Create a bitmap from the image frame
					WICBitmapCacheOnDemand,  // Cache metadata when needed
					&pIBitmap);              // Pointer to the bitmap
				piBitmapFrame->WriteSource(pIBitmap, &rcLock);
				counter = pIBitmap->Release();

			}
		}
		//    else
		{
		//        hr = E_OUTOFMEMORY;
	}
	}

	if (SUCCEEDED(hr))
	{
		hr = piBitmapFrame->Commit();
	}

	if (SUCCEEDED(hr))
	{
		hr = piEncoder->Commit();
	}

	if (piFactory)
		counter = piFactory->Release();

	if (piBitmapFrame)
		counter = piBitmapFrame->Release();

	if (piBitmapFrameIn)
		counter = piBitmapFrameIn->Release();

	if (piDecoder)
		counter = piDecoder->Release();

	if (piEncoder)
		counter = piEncoder->Release();

	if (piStream)
		counter = piStream->Release();

	if (piStreamIn)
		counter = piStreamIn->Release();

	if (pPropertybag)
		counter = pPropertybag->Release();

	CoUninitialize();
	return hr;
}



bool IsRGBA(const std::wstring& strFileName)
{
	unsigned char buf[4] = { 0 };
	std::fstream fs(strFileName, std::ios::in | std::ios::binary);
	fs.seekg(4, SEEK_SET);
	fs.read((char*)&buf, 4);
	int pos = (buf[3] << 24) + (buf[2] << 16) + (buf[1] << 8) + buf[0];
	while (pos > 0)
	{
		fs.seekg(pos, SEEK_SET);
		fs.read((char*)&buf, 2);
		int numEntry = (buf[1] << 8) + buf[0];
		fs.seekg(12 * numEntry, SEEK_CUR);
		fs.read((char*)&buf, 4);
		pos = (buf[3] << 24) + (buf[2] << 16) + (buf[1] << 8) + buf[0];
	}
	fs.seekg(15, SEEK_CUR);
	fs.read((char*)&buf, 1);
	if (buf[0] == 0x0F)
		return true;
	else
		return false;
}

int main(){
	printf("0\n");
	WCHAR* szPngFileName = L"D:\\abd.bmp";
	WCHAR* szWdpFileName = L"D:\\clipnext2.jpg";

	PNG2WDP(szPngFileName, szWdpFileName);

	printf("end\n");
	system("pause");
	return 0;
}