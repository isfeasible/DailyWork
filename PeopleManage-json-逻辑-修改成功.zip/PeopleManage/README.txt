在这个版本中实现了json并且存储到本地的功能：
1. 现在debug文件夹下自己放入save,json，内容参考为0样式的那个txt
2. 在init是loadGame
3. 当点击添加按钮时放入一些新数据到mNpcs中，即那个List中，随后再存入save.json中