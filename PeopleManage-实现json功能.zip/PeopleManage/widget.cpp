#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    if (!level.loadGame()){
        qDebug()<<"level loadGame failed";
    }


}

Widget::~Widget()
{
    delete ui;
}

// 添加按钮
void Widget::on_pushButton_clicked()
{
    qDebug()<<"添加按钮";

    /*QList<Character> villageNpcs;
    villageNpcs.append(Character("1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"));
    villageNpcs.append(Character("2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2"));
    level.setNpcs(villageNpcs);

    if (!level.saveGame()){
        qDebug()<<"level saveGame failed";
        return;
    }*/

    /*QList<Character> villageNpcs;
    villageNpcs.append(Character("1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1"));
    villageNpcs.append(Character("2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2"));
    level.setNpcs(villageNpcs);

    if (!level.saveGame()){
        qDebug()<<"level saveGame failed";
        return;
    }*/

    level.npcs().append(Character("221", "221", "21", "21", "21", "21", "21", "21", "21", "21", "21", "21", "21", "21", "21", "21"));
    level.npcs().append(Character("222", "222", "22", "22", "22", "22", "22", "22", "22", "22", "22", "22", "22", "22", "22", "22"));

    if (!level.saveGame()){
        qDebug()<<"level saveGame failed";
        return;
    }

    QMessageBox::about(NULL, "提示", "添加成功");
}

