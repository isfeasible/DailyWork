#define _INTEGRAL_MAX_BITS 64
#define _MSC_VER 1800
#define _MSC_FULL_VER 180021005
#define _MSC_BUILD 1
#define _WIN32 
#define _M_IX86 600
#define _M_IX86_FP 2
#define _DEBUG 
#define _MT 
#define _DLL 
#define _CPPRTTI 
