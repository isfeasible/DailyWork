#include "widget.h"
#include "ui_widget.h"
#include <QAxObject>
#include <QDebug>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);


}

Widget::~Widget()
{
    delete ui;
}

// 从excel导入
void Widget::on_pushButton_clicked()
{
    qDebug()<<"读Excel";
    QAxObject *excel = new QAxObject(this);
    excel->setControl("Excel.Application");//连接Excel控件
    excel->dynamicCall("SetVisible (bool Visible)","false");//不显示窗体
    excel->setProperty("DisplayAlerts", false);//不显示任何警告信息。如果为true那么在关闭是会出现类似“文件已修改，是否保存”的提示
    QAxObject *work_books = excel->querySubObject("WorkBooks");
    work_books->dynamicCall("Open (const QString&)", QString("D:/test.xlsx"));
    QVariant title_value = excel->property("Caption");  //获取标题
    qDebug()<<QString("excel title : ")<<title_value;
    QAxObject *work_book = excel->querySubObject("ActiveWorkBook");
    QAxObject *work_sheets = work_book->querySubObject("Sheets");  //Sheets也可换用WorkSheets

    int sheet_count = work_sheets->property("Count").toInt();  //获取工作表数目
    qDebug()<<QString("sheet count : ")<<sheet_count;

    for(int i=1; i<=sheet_count; i++)
    {
    QAxObject *work_sheet = work_book->querySubObject("Sheets(int)", i);  //Sheets(int)也可换用Worksheets(int)
    QString work_sheet_name = work_sheet->property("Name").toString();  //获取工作表名称
    QString message = QString("sheet ")+QString::number(i, 10)+ QString(" name");
    qDebug()<<message<<work_sheet_name;
    }

    if(sheet_count > 0)
    {
        QAxObject *work_sheet = work_book->querySubObject("Sheets(int)", 1);
        QAxObject *used_range = work_sheet->querySubObject("UsedRange");
        QAxObject *rows = used_range->querySubObject("Rows");
        QAxObject *columns = used_range->querySubObject("Columns");
        int row_start = used_range->property("Row").toInt();  //获取起始行
        int column_start = used_range->property("Column").toInt();  //获取起始列
        int row_count = rows->property("Count").toInt();  //获取行数
        int column_count = columns->property("Count").toInt();  //获取列数

        qDebug()<<"row_start:"<<row_start;
        qDebug()<<"column_start"<<column_start;
        qDebug()<<"row_count"<<row_count;
        qDebug()<<"column_count"<<column_count;


        for(int i=row_start; i<=row_count;i++)
        {
            for(int j=column_start; j<=column_count;j++)
            {
                QAxObject *cell = work_sheet->querySubObject("Cells(int,int)", i, j);
                QVariant cell_value = cell->property("Value");  //获取单元格内容
                QString message = QString("row-")+QString::number(i, 10)+QString("-column-")+QString::number(j, 10)+QString(":");
                qDebug()<<message<<cell_value;
            }
        }
    }
}

// 导出到excel
void Widget::on_pushButton_2_clicked()
{
    qDebug()<<"写Excel";
    QAxObject *excel = new QAxObject(this);
    excel->setControl("Excel.Application");//连接Excel控件
    excel->setProperty("Visible", false);
    excel->setProperty("DisplayAlerts", false);
    QAxObject *work_books = excel->querySubObject("WorkBooks");
    work_books->dynamicCall("Add");//新建一个工作簿
    QAxObject *workbook = excel->querySubObject("ActiveWorkBook");//获取当前工作簿
    QAxObject *worksheets = workbook->querySubObject("Sheets");//获取工作表集合
    QAxObject *worksheet = worksheets->querySubObject("Item(int)",1);//获取工作表集合的工作表1，即sheet1

    QAxObject *cell = worksheet->querySubObject("Cells(int,int)", 2, 2);
    cell->setProperty("Value", "Java C++ C# PHP Perl Python Delphi Ruby");  //设置单元格值
    QAxObject *cell2 = worksheet->querySubObject("Cells(int,int)", 6, 6);
    cell2->setProperty("Value", "My name is chneshneg by me!");  //设置单元格值

    QAxObject *range = worksheet->querySubObject("UsedRange");
    QAxObject *cells = range->querySubObject("Columns");
    cells->dynamicCall("AutoFit");

    workbook->dynamicCall("SaveAs(const QString&)", "D:\\test2.xlsx");

    workbook->dynamicCall("Close()");//关闭工作簿
    excel->dynamicCall("Quit()");//关闭excel
    delete excel;
    excel = NULL;
    qDebug()<<"end";

}
