#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>
#include <QAxObject>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("人事管理系统");
    if (!level.loadGame()){
        qDebug()<<"level loadGame failed";
    }


}

Widget::~Widget()
{
    delete ui;
}

// 添加按钮
void Widget::on_pushButton_clicked()
{
    qDebug()<<"添加按钮";
    Character firstOne;

    if(ui->lineEdit->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少姓名");
        return;
    }
    if(ui->lineEdit_3->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少身份证号");
        return;
    }
    if(ui->lineEdit_4->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少户口所在地");
        return;
    }
    if(ui->lineEdit_5->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少籍贯");
        return;
    }
    if(ui->lineEdit_6->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少联系电话");
        return;
    }
    if(ui->lineEdit_7->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少银行卡号");
        return;
    }
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少员工编号");
        return;
    }
    if(ui->lineEdit_10->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少工龄");
        return;
    }

    QString Person_ID = ui->lineEdit_3->text();
    QString YuanGongID = ui->lineEdit_8->text();

    foreach (const Character npc, level.npcs()) {
        if (npc.Person_ID() == Person_ID){
            QMessageBox::about(NULL, "错误", "身份证号重复");
            return;
        }
    }
    foreach (const Character npc, level.npcs()) {
        if (npc.YuanGongID() == YuanGongID){
            QMessageBox::about(NULL, "错误", "员工编号重复");
            return;
        }
    }

    firstOne.setName(ui->lineEdit->text());
    firstOne.setGender(ui->comboBox->currentText());
    firstOne.setBirthDate(ui->dateEdit->dateTime().toString("yyyy-MM-dd"));
    firstOne.setPerson_ID(ui->lineEdit_3->text());
    firstOne.setXueli(ui->comboBox_2->currentText());
    firstOne.setHukou(ui->lineEdit_4->text());
    firstOne.setJiGuan(ui->lineEdit_5->text());
    firstOne.setPhoneNumber(ui->lineEdit_6->text());
    firstOne.setBankID(ui->lineEdit_7->text());

    firstOne.setYuanGongID(ui->lineEdit_8->text());
    firstOne.setBumen(ui->comboBox_3->currentText());
    firstOne.setZhiwei(ui->comboBox_4->currentText());
    firstOne.setRuzhiDate(ui->dateEdit_2->dateTime().toString("yyyy-MM-dd"));
    firstOne.setGongLin(ui->lineEdit_10->text());
    firstOne.setZhuangTai(ui->comboBox_5->currentText());
    firstOne.setBeizhu(ui->textEdit->toPlainText());

    level.appendCharacter(firstOne);
    QMessageBox::about(NULL, "提示", "添加成功");
}

// 修改按钮
void Widget::on_pushButton_2_clicked()
{
    bool if_existed = false;
    int index = 0;

    qDebug()<<"修改按钮";
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少修改用的员工编号");
        return;
    }
    QString YuanGongID = ui->lineEdit_8->text();
    foreach (const Character npc, level.npcs()) {
        if (npc.YuanGongID() == YuanGongID){
            if_existed = true;
            break;
        }
        index++;
    }

    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }else{
        if(ui->lineEdit->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少姓名");
            return;
        }
        if(ui->lineEdit_3->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少身份证号");
            return;
        }
        if(ui->lineEdit_4->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少户口所在地");
            return;
        }
        if(ui->lineEdit_5->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少籍贯");
            return;
        }
        if(ui->lineEdit_6->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少联系电话");
            return;
        }
        if(ui->lineEdit_7->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少银行卡号");
            return;
        }
        if(ui->lineEdit_10->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少工龄");
            return;
        }

        QString Person_ID = ui->lineEdit_3->text();
        foreach (const Character npc, level.npcs()) {
            if (npc.Person_ID() == Person_ID && npc.YuanGongID() != YuanGongID){
                QMessageBox::about(NULL, "错误", "身份证号与其他人重复");
                return;
            }
        }

        Character secOne;
        secOne.setName(ui->lineEdit->text());
        secOne.setGender(ui->comboBox->currentText());
        secOne.setBirthDate(ui->dateEdit->dateTime().toString("yyyy-MM-dd"));
        secOne.setPerson_ID(ui->lineEdit_3->text());
        secOne.setXueli(ui->comboBox_2->currentText());
        secOne.setHukou(ui->lineEdit_4->text());
        secOne.setJiGuan(ui->lineEdit_5->text());
        secOne.setPhoneNumber(ui->lineEdit_6->text());
        secOne.setBankID(ui->lineEdit_7->text());

        secOne.setYuanGongID(ui->lineEdit_8->text());
        secOne.setBumen(ui->comboBox_3->currentText());
        secOne.setZhiwei(ui->comboBox_4->currentText());
        secOne.setRuzhiDate(ui->dateEdit_2->dateTime().toString("yyyy-MM-dd"));
        secOne.setGongLin(ui->lineEdit_10->text());
        secOne.setZhuangTai(ui->comboBox_5->currentText());
        secOne.setBeizhu(ui->textEdit->toPlainText());

        level.updateCharacter(index, secOne);

        QMessageBox::about(NULL, "提示", "修改成功");
    }

}

// 查询按钮
void Widget::on_pushButton_3_clicked()
{
    qDebug()<<"查询按钮";
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少查询用的员工编号");
        return;
    }
    bool if_existed = false;
    QString YuanGongID = ui->lineEdit_8->text();
    foreach (const Character npc, level.npcs()) {
        if (npc.YuanGongID() == YuanGongID){
            if_existed = true;

            ui->lineEdit->setText(npc.name());
            ui->comboBox->setCurrentText(npc.gender());
            QString strBuffer = npc.BirthDate();
            ui->dateEdit->setDateTime(QDateTime::fromString(strBuffer, "yyyy-MM-dd"));
            ui->lineEdit_3->setText(npc.Person_ID());
            ui->comboBox_2->setCurrentText(npc.Xueli());
            ui->lineEdit_4->setText(npc.Hukou());
            ui->lineEdit_5->setText(npc.JiGuan());
            ui->lineEdit_6->setText(npc.PhoneNumber());
            ui->lineEdit_7->setText(npc.BankID());
            ui->lineEdit_8->setText(npc.YuanGongID());
            ui->comboBox_3->setCurrentText(npc.Bumen());
            ui->comboBox_4->setCurrentText(npc.Zhiwei());
            strBuffer = npc.RuzhiDate();
            ui->dateEdit_2->setDateTime(QDateTime::fromString(strBuffer, "yyyy-MM-dd"));
            ui->lineEdit_10->setText(npc.GongLin());
            ui->comboBox_5->setCurrentText(npc.ZhuangTai());
            ui->textEdit->setPlainText(npc.Beizhu());
        }
    }

    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }

    QMessageBox::about(NULL, "提示", "查询成功");
}

// 删除按钮
void Widget::on_pushButton_4_clicked()
{
    bool if_existed = false;
    int index = 0;

    qDebug()<<"删除按钮";
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少删除用的员工编号");
        return;
    }

    QString YuanGongID = ui->lineEdit_8->text();
    foreach (const Character npc, level.npcs()) {
        if (npc.YuanGongID() == YuanGongID){
            if_existed = true;
            break;
        }
        index++;
    }
    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }else{
        level.deleteCharacter(index);

        ui->lineEdit->setText("");
        ui->lineEdit_3->setText("");
        ui->lineEdit_4->setText("");
        ui->lineEdit_5->setText("");
        ui->lineEdit_6->setText("");
        ui->lineEdit_7->setText("");
        //ui->lineEdit_8->setText("");
        ui->lineEdit_10->setText("");
        ui->textEdit->setPlainText("");

        QMessageBox::about(NULL, "提示", "删除成功");
    }
}

//清空按钮
void Widget::on_pushButton_5_clicked()
{
    qDebug()<<"清空按钮";
    ui->lineEdit->setText("");
    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");
    ui->lineEdit_5->setText("");
    ui->lineEdit_6->setText("");
    ui->lineEdit_7->setText("");
    ui->lineEdit_8->setText("");
    ui->lineEdit_10->setText("");
    ui->textEdit->setPlainText("");
    QMessageBox::about(NULL, "提示", "清空成功");
}

// 调试按钮
void Widget::on_pushButton_7_clicked()
{
    qDebug()<<"调试按钮";
    if (!level.saveGame()){
        qDebug()<<"Debug: level saveGame failed";
        return;
    }

    QMessageBox::about(NULL, "提示", "写入json成功");
}

// 显示内容
void Widget::on_pushButton_8_clicked()
{
    int index = 0;
    qDebug()<<"显示内容按钮";
    foreach (const Character npc, level.npcs()) {
        qDebug()<<index<<"  -----------------------------------";
        qDebug()<<npc.name();
        qDebug()<<npc.gender();
        qDebug()<<npc.BirthDate();
        qDebug()<<npc.Person_ID();
        qDebug()<<npc.Xueli();
        qDebug()<<npc.Hukou();
        qDebug()<<npc.JiGuan();
        qDebug()<<npc.PhoneNumber();
        qDebug()<<npc.BankID();
        qDebug()<<npc.YuanGongID();
        qDebug()<<npc.Bumen();
        qDebug()<<npc.Zhiwei();
        qDebug()<<npc.RuzhiDate();
        qDebug()<<npc.GongLin();
        qDebug()<<npc.ZhuangTai();
        qDebug()<<npc.Beizhu();
        index++;
    }
}

// 生成数据库
void Widget::on_pushButton_9_clicked()
{
    int quanlity = 1000;
    int index;
    Character firstOne = level.npcs().at(0);
    QString editContent = "";

    qDebug()<<"Create Database";
    for(index=1; index<quanlity; ++index){
        Character tempOne;
        tempOne.setName(firstOne.name());
        tempOne.setGender(firstOne.gender());
        tempOne.setBirthDate(firstOne.BirthDate());
        editContent = "9" + QString::number(index, 10);
        tempOne.setPerson_ID(editContent);
        tempOne.setXueli(firstOne.Xueli());
        tempOne.setHukou(firstOne.Hukou());
        tempOne.setJiGuan(firstOne.JiGuan());
        tempOne.setPhoneNumber(firstOne.PhoneNumber());
        tempOne.setBankID(firstOne.BankID());
        editContent = QString::number(index, 10);
        tempOne.setYuanGongID(editContent);
        tempOne.setBumen(firstOne.Bumen());
        tempOne.setZhiwei(firstOne.Zhiwei());
        tempOne.setRuzhiDate(firstOne.RuzhiDate());
        tempOne.setGongLin(firstOne.GongLin());
        tempOne.setZhuangTai(firstOne.ZhuangTai());
        tempOne.setBeizhu(firstOne.Beizhu());

        level.appendCharacter(tempOne);
    }
    qDebug()<<"Create Database successfully!";

}

// 从excel导入
void Widget::on_pushButton_10_clicked()
{

    qDebug()<<"创建并写入Excel";
    QAxObject *excel = new QAxObject("Excel.Application");
    if (excel==NULL) {
        qDebug()<<"excel new failed";
        return;
    }
    excel->setProperty("Visible", false);
    excel->setProperty("DisplayAlerts", false);
    QAxObject * workbooks = excel->querySubObject("WorkBooks");
    if (workbooks==NULL) 	{
        qDebug()<<"get WorkBooks failed";
        return;
    }
    workbooks->dynamicCall("Open (const QString&)", QString("D:\\test.xlsx"));
    QAxObject * workbook = excel->querySubObject("ActiveWorkBook");
    if (workbook==NULL) 	{
        qDebug()<<"get ActiveWorkBook failed";
        return;
    }
    QAxObject * workSheet = workbook->querySubObject("Worksheets(int)",1);
    if (workSheet==NULL) 	{
        qDebug()<<"get sheet one failed";
        return;
    }

    QAxObject *used_range = workSheet->querySubObject("UsedRange");
    QVariant var = used_range->dynamicCall("Value");

    /*********************************************/
    QList<QList<QVariant>> res;
    QVariantList varRows = var.toList();
    if(varRows.isEmpty())
    {
        qDebug()<<"varRow is empty";
        return;
    }
    const int rowCount = varRows.size();
    QVariantList rowData;
    for(int i=0;i<rowCount;++i)
    {
        rowData = varRows[i].toList();
        res.push_back(rowData);
    }
    /*********************************************/

    level.clearList();
    qDebug()<<"clear the list of level";


    int index = 0;
    foreach (const QList<QVariant> irow, res) {
        if(index == 0){
            index++;
            continue;
        }
        Character tempOne;
        tempOne.setName(irow.at(0).toString());
        tempOne.setGender(irow.at(1).toString());
        tempOne.setBirthDate(irow.at(2).toDateTime().toString("yyyy-MM-dd"));
        tempOne.setPerson_ID(irow.at(3).toString());
        tempOne.setXueli(irow.at(4).toString());
        tempOne.setHukou(irow.at(5).toString());
        tempOne.setJiGuan(irow.at(6).toString());
        tempOne.setPhoneNumber(irow.at(7).toString());
        tempOne.setBankID(irow.at(8).toString());
        tempOne.setYuanGongID(irow.at(9).toString());
        tempOne.setBumen(irow.at(10).toString());
        tempOne.setZhiwei(irow.at(11).toString());
        tempOne.setRuzhiDate(irow.at(12).toDateTime().toString("yyyy-MM-dd"));
        tempOne.setGongLin(irow.at(13).toString());
        tempOne.setZhuangTai(irow.at(14).toString());
        tempOne.setBeizhu(irow.at(15).toString());
        level.appendCharacter(tempOne);
    }

    workbook->dynamicCall("Close()");//关闭工作簿
    excel->dynamicCall("Quit()");//关闭excel
    delete excel;
    excel=NULL;
    QMessageBox::about(NULL, "提示", "读入excel成功");
}

// 导出到excel
void Widget::on_pushButton_11_clicked()
{
    //Character firstOne("陈胜", "男", "2017-05-20", "1234567891234567891234", "大学", "凤台", "安徽", "13352406086", "1", "成型B后", "普工", "2017-05-10", "1000", "在职", "测试");

    qDebug()<<"创建并写入Excel";
    QAxObject *excel = new QAxObject("Excel.Application");
    if (excel==NULL) {
        qDebug()<<"excel new failed";
        return;
    }
    excel->setProperty("Visible", false);
    excel->setProperty("DisplayAlerts", false);
    QAxObject * workbooks = excel->querySubObject("WorkBooks");
    if (workbooks==NULL) 	{
        qDebug()<<"get WorkBooks failed";
        return;
    }
    workbooks->dynamicCall("Add");
    QAxObject * workbook = excel->querySubObject("ActiveWorkBook");
    if (workbook==NULL) 	{
        qDebug()<<"get ActiveWorkBook failed";
        return;
    }
    QAxObject * workSheet = workbook->querySubObject("Worksheets(int)",1);
    if (workSheet==NULL) 	{
        qDebug()<<"get sheet one failed";
        return;
    }

    //QAxObject *used_range = workSheet->querySubObject("UsedRange");

    QVariantList varlist;
    QVariantList titleLine;
    titleLine.append(QVariant("\345\247\223\345\220\215"));  // 姓名
    titleLine.append(QVariant("\346\200\247\345\210\253"));             // 性别
    titleLine.append(QVariant("\345\207\272\347\224\237\346\227\245\346\234\237"));   //出生日期
    titleLine.append(QVariant("\350\272\253\344\273\275\350\257\201\345\217\267"));   // 身份证号
    titleLine.append(QVariant("\345\255\246\345\216\206"));      //学历
    titleLine.append(QVariant("\346\210\267\345\217\243\346\211\200\345\234\250\345\234\260"));  //户口所在地
    titleLine.append(QVariant("\347\261\215\350\264\257"));       // 籍贯
    titleLine.append(QVariant("\350\201\224\347\263\273\347\224\265\350\257\235"));    // 联系电话
    titleLine.append(QVariant("\351\223\266\350\241\214\345\215\241"));      // 银行卡
    titleLine.append(QVariant("\345\221\230\345\267\245\347\274\226\345\217\267"));    // 员工编号
    titleLine.append(QVariant("\351\203\250\351\227\250"));       // 部门
    titleLine.append(QVariant("\350\201\214\344\275\215"));       // 职位
    titleLine.append(QVariant("\345\205\245\350\201\214\346\227\245\346\234\237"));    // 入职日期
    titleLine.append(QVariant("\345\267\245\351\276\204"));       // 工龄
    titleLine.append(QVariant("\347\212\266\346\200\201"));       // 状态
    titleLine.append(QVariant("\345\244\207\346\263\250"));       // 备注

    // 添加标题
    varlist.append(QVariant(titleLine));

    QList<Character> mNpcs = level.npcs();
    int rows = mNpcs.size();
    for(int i=0; i<rows; ++i)
    {
        QVariantList eachrow;

        eachrow.append(mNpcs[i].name());
        eachrow.append(mNpcs[i].gender());
        eachrow.append(mNpcs[i].BirthDate());
        QString pid = mNpcs[i].Person_ID();
        eachrow.append(pid);
        eachrow.append(mNpcs[i].Xueli());
        eachrow.append(mNpcs[i].Hukou());
        eachrow.append(mNpcs[i].JiGuan());
        eachrow.append(mNpcs[i].PhoneNumber());
        eachrow.append(mNpcs[i].BankID());
        eachrow.append(mNpcs[i].YuanGongID());
        eachrow.append(mNpcs[i].Bumen());
        eachrow.append(mNpcs[i].Zhiwei());
        eachrow.append(mNpcs[i].RuzhiDate());
        eachrow.append(mNpcs[i].GongLin());
        eachrow.append(mNpcs[i].ZhuangTai());
        eachrow.append(mNpcs[i].Beizhu());

        varlist.append(QVariant(eachrow));
    }

    QVariant vars = QVariant(varlist);

    QString rangStr = "A1:P";
    rangStr += QString::number(rows+1);      // 有一行标题栏
    QAxObject *range = workSheet->querySubObject("Range(const QString&)",rangStr);
    // 设置单元格格式为文本
    range->setProperty("NumberFormatLocal", "@");  // 设置为文本

    bool succ = false;
    succ = range->setProperty("Value", vars);
    if (!succ){
        qDebug()<<"write range failed";
        return;
    }

    QAxObject *range2 = workSheet->querySubObject("UsedRange");
    QAxObject *cells = range2->querySubObject("Columns");
    cells->dynamicCall("AutoFit");

    workbook->dynamicCall("SaveAs(const QString&)", "D:\\test2.xlsx");  //另存为另一个文件
    workbook->dynamicCall("Close(Boolean)", false);  //关闭文件
    excel->dynamicCall("Quit(void)");  //退出

    delete excel;
    excel = NULL;
    QMessageBox::about(NULL, "提示", "写入excel成功");

}
