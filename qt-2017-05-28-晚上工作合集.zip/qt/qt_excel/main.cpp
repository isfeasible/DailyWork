#include "qt_excel_new.h"
#include <QApplication>
#include<QString>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QString fileName="C:\\Users\\Administrator\\Desktop\\xuan.xls";
    qt_excel_new excel;
    excel.newExcel(fileName);
    excel.doExcel();
    excel.freeExcel();
    getchar();
    return a.exec();
}
