#include "qt_excel_new.h"

#include<QtGui>
#include <QtWidgets/QApplication>
#include <ActiveQt\qaxobject.h>
#include <ActiveQt\qaxwidget.h>
#include<ActiveQt\qaxselect.h>
#include <QVariant>
#include <QDebug>

qt_excel_new::qt_excel_new(QWidget *parent)
    : QWidget(parent)
{
#if defined(Q_OS_WIN)
qDebug()<<"hello";
#endif // Q_OS_WIN
}

qt_excel_new::~qt_excel_new()
{

}
void qt_excel_new::newExcel(const QString &fileName)
{
    //fileName= Application.GetOpenFilename("C:\\Users\\Administrator\\Desktop\\xuan,*.xls");
     /*QString fileName="C:\\Users\\Administrator\\Desktop\\xuan.xls";*/

    pApplication=new QAxObject();
    pApplication->setControl("Excel.Application");//连接Excel控件
    //pApplication->dynamicCall("SetVisible(bool)",false);//false不显示窗体，参量不是用来显示excel表
    pApplication->dynamicCall("SetVisible(bool)",true);//false显示窗体,启动excel，但是却没有sheet页面
   // pApplication->dynamicCall("Add (void)");//不显示任何警告信息，不知道起什么作用
    pWorkBooks=pApplication->querySubObject("Workbooks");
    QFile file(fileName);
    if(file.exists())
     {
        pWorkBook=pWorkBooks->querySubObject("Open(const QString &)",fileName);
        //pWorkBook=pWorkBooks->querySubObject("Open(const Qstring&)","C:\\Users\\Administrator\\Desktop\\xuan.xls");
     }
    else
     {
        pWorkBooks->dynamicCall("Add");//加载了sheet
        pWorkBook=pApplication->querySubObject("ActiveWorkBook");
        //pWorkBook=pWorkBooks->querySubObject("Open(const QString &)",fileName);
        pWorkBook->dynamicCall("SaveAs(const QString&)",fileName);//文件另存为
     }//到此位置已经新建好一个.xls文件



}
void qt_excel_new::doExcel()//对Excel的sheet内容进行操作
{
    pSheets=pWorkBook->querySubObject("Sheets");
    pSheet=pSheets->querySubObject("Item(int)",1);
    //删除工作表(删除第一个)
    /*QAxObject* second_sheet=pSheets->querySubObject("Item(int)",2);
    second_sheet->dynamicCall("delete");
    QAxObject* third_sheet=pSheets->querySubObject("Item(int)",3);
    third_sheet->dynamicCall("delete");*/

    QAxObject* cell1_1=pSheet->querySubObject("Cells(int,int)",1,1);
    cell1_1->dynamicCall("Value","Sequence Number");
    cell1_1->setProperty("HorizontalAlignment",-4108);//左对齐(xlLeft):-4131
    //居中（xlCenter）:-4180 右对齐(xlRight):-4152
    cell1_1->setProperty("VerticalAlignment",-4108);//上对齐(xlTop)-4160
    //居中(xlCenter):-4108 下对齐(xlBottom):-4107
    cell1_1->setProperty("WarpText",true);//内容过多自动换行
    //cell->dynamicCall("ClearContents()");//清空单元格内容
    cell1_1->setProperty("ColumnWidth",15);//设置单元格列宽
    QAxObject* border1_1=cell1_1->querySubObject("Borders");
    border1_1->setProperty("Color",QColor(0,0,255));//设置单元格背景(蓝色)


    QAxObject* cell1_2=pSheet->querySubObject("Cells(int,int)",1,2);
    cell1_2->dynamicCall("Value","Name");
    cell1_2->setProperty("HorizontalAlignment",-4108);//左对齐(xlLeft):-4131
    cell1_2->setProperty("VerticalAlignment",-4108);//上对齐(xlTop)-4160
    cell1_2->setProperty("WarpText",true);//内容过多自动换行
    QAxObject* border1_2=cell1_2->querySubObject("Borders");
    border1_2->setProperty("Color",QColor(0,0,255));//设置单元格背景(蓝色)

    QAxObject* cell1_3=pSheet->querySubObject("Cells(int,int)",1,3);
    cell1_3->dynamicCall("Value","Agree(number)");
    cell1_3->setProperty("HorizontalAlignment",-4108);//左对齐(xlLeft):-4131
    cell1_3->setProperty("VerticalAlignment",-4108);//上对齐(xlTop)-4160
    cell1_3->setProperty("WarpText",true);//内容过多自动换行
    cell1_3->setProperty("ColumnWidth",15);//设置单元格列宽
    QAxObject* border1_3=cell1_3->querySubObject("Borders");
    border1_3->setProperty("Color",QColor(0,0,255));//设置单元格背景(蓝色)


    QAxObject* cell1_4=pSheet->querySubObject("Cells(int,int)",1,4);
    cell1_4->dynamicCall("Value","disAgree(number)");
    cell1_4->setProperty("HorizontalAlignment",-4108);//左对齐(xlLeft):-4131
    cell1_4->setProperty("VerticalAlignment",-4108);//上对齐(xlTop)-4160
    cell1_4->setProperty("WarpText",true);//内容过多自动换行
    cell1_4->setProperty("ColumnWidth",18);//设置单元格列宽abstention
    QAxObject* border1_4=cell1_4->querySubObject("Borders");
    border1_4->setProperty("Color",QColor(0,0,255));//设置单元格背景(蓝色)

    QAxObject* cell1_5=pSheet->querySubObject("Cells(int,int)",1,5);
    cell1_5->dynamicCall("Value","abStention(number)");
    cell1_5->setProperty("HorizontalAlignment",-4108);//左对齐(xlLeft):-4131
    cell1_5->setProperty("VerticalAlignment",-4108);//上对齐(xlTop)-4160
    cell1_5->setProperty("WarpText",true);//内容过多自动换行
    cell1_5->setProperty("ColumnWidth",18);//设置单元格列宽
    QAxObject* border1_5=cell1_5->querySubObject("Borders");
    border1_5->setProperty("Color",QColor(0,0,255));//设置单元格背景(蓝色)

    for (int t1 = 1; t1 < 6; t1++)
    {
        QAxObject* cell=pSheet->querySubObject("Cells(int,int)",1,t1);
        QAxObject* font=cell->querySubObject("Font");//获取单元格字体
        font->setProperty("Bold",true);//设置单元格字体加粗
        font->setProperty("Size",10);//设置单元格字体大小
    }

    for (int i = 2; i < 15; i++)
    {
            QAxObject* cell2_1=pSheet->querySubObject("Cells(int,int)",i,1);
            cell2_1->setProperty("Value",i-1);//设置单元格值
            cell2_1->setProperty("HorizontalAlignment",-4108);//左对齐(xlLeft):-4131
            //居中（xlCenter）:-4180 右对齐(xlRight):-4152
            cell2_1->setProperty("VerticalAlignment",-4108);//上对齐(xlTop)-4160
            //居中(xlCenter):-4108 下对齐(xlBottom):-4107
            cell2_1->setProperty("WarpText",true);//内容过多自动换行


            for (int j = 1; j < 6; j++)
        {
             QAxObject* cell=pSheet->querySubObject("Cells(int,int)",i,j);
             QAxObject* border=cell->querySubObject("Borders");
             border->setProperty("Color",QColor(0,0,255));//设置单元格背景(蓝色)
             if (1==i%2)
             {
                 QAxObject* interior=cell->querySubObject("interior");
                 interior->setProperty("Color",QColor(0,255,0));//设置单元格背景(绿色)
             }
        }

    }
}
void qt_excel_new::freeExcel()//这里是释放掉这个excel表,或者是关闭显示的excel表
{
    if (pApplication!=NULL)
        {
            pApplication->dynamicCall("Quit()");
            delete pApplication;
            pApplication=NULL;
        }
}
