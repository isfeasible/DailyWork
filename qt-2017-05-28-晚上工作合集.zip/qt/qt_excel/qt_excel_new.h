#ifndef QT_EXCEL_NEW_H
#define QT_EXCEL_NEW_H

#include<QtWidgets/QWidget>
#include<ActiveQt/qaxobject.h>
#include <ActiveQt\qaxwidget.h>
#include<ActiveQt\qaxselect.h>

class qt_excel_new : public QWidget
{
    Q_OBJECT

public:
    qt_excel_new(QWidget *parent = 0);
    QAxObject* pApplication;
    QAxObject* pWorkBooks;
    QAxObject* pWorkBook;
    QAxObject* pSheets;
    QAxObject* pSheet;
    void newExcel(const QString &fileName);
    void freeExcel();
    void doExcel();
    ~qt_excel_new();
};

#endif // QT_EXCEL_NEW_H
