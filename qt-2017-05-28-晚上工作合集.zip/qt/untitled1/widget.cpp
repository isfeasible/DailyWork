#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QVariant>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QVariant v(123);
    QVariant s("123");  // The variant now contains an int
    qDebug()<<v;
    qDebug()<<s;
    if(v.type() == QMetaType::Int ){
        qDebug()<<"int true";
        qDebug()<<"type:"<<v.type();
    }
    if(s.type() == QMetaType::QString ){
        qDebug()<<"string true";
        qDebug()<<"type:"<<s.type();
    }

    QVariant  str("姓名");
    qDebug()<< str;
    QString str2("\345\247\223\345\220\215");
    qDebug()<<str2;
     /*int x = v.toInt();
     QString y = v.toString();
     qDebug()<<x;
     qDebug()<<y;

     if(v.canConvert<int>()){
        int indx = v.toInt();
        qDebug()<<"int: "<<indx;
     };
     if(v.canConvert<QString>()){
         QString rec = v.toString();
         qDebug()<<"String : "<<rec;

     }*/

}

Widget::~Widget()
{
    delete ui;
}
