#include "widget.h"
#include "ui_widget.h"
#include <QAxObject>
#include <QDebug>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    //QString test = "56";
    //qDebug()<<test;
    //int index = 90;
    //test = "test" + QString::number(index, 10);
    //qDebug()<<test;
    //QAxObject excel("Excel.Application");

}

Widget::~Widget()
{
    delete ui;
}

// 从excel导入
void Widget::on_pushButton_clicked()
{
    qDebug()<<"读Excel";
    QAxObject excel("Excel.Application");
    excel.setProperty("Visible", true);
    QAxObject *work_books = excel.querySubObject("WorkBooks");
    work_books->dynamicCall("Open (const QString&)", QString("D:/test.xlsx"));
    QVariant title_value = excel.property("Caption");  //获取标题
    qDebug()<<QString("excel title : ")<<title_value;
    QAxObject *work_book = excel.querySubObject("ActiveWorkBook");
    QAxObject *work_sheets = work_book->querySubObject("Sheets");  //Sheets也可换用WorkSheets

    int sheet_count = work_sheets->property("Count").toInt();  //获取工作表数目
    qDebug()<<QString("sheet count : ")<<sheet_count;

    for(int i=1; i<=sheet_count; i++)
    {
    QAxObject *work_sheet = work_book->querySubObject("Sheets(int)", i);  //Sheets(int)也可换用Worksheets(int)
    QString work_sheet_name = work_sheet->property("Name").toString();  //获取工作表名称
    QString message = QString("sheet ")+QString::number(i, 10)+ QString(" name");
    qDebug()<<message<<work_sheet_name;
    }

    if(sheet_count > 0)
    {
        QAxObject *work_sheet = work_book->querySubObject("Sheets(int)", 1);
        QAxObject *used_range = work_sheet->querySubObject("UsedRange");
        QAxObject *rows = used_range->querySubObject("Rows");
        QAxObject *columns = used_range->querySubObject("Columns");
        int row_start = used_range->property("Row").toInt();  //获取起始行
        int column_start = used_range->property("Column").toInt();  //获取起始列
        int row_count = rows->property("Count").toInt();  //获取行数
        int column_count = columns->property("Count").toInt();  //获取列数

        qDebug()<<"row_start:"<<row_start;
        qDebug()<<"column_start"<<column_start;
        qDebug()<<"row_count"<<row_count;
        qDebug()<<"column_count"<<column_count;


        for(int i=row_start; i<=row_count;i++)
        {
            for(int j=column_start; j<=column_count;j++)
            {
                QAxObject *cell = work_sheet->querySubObject("Cells(int,int)", i, j);
                QVariant cell_value = cell->property("Value");  //获取单元格内容
                QString message = QString("row-")+QString::number(i, 10)+QString("-column-")+QString::number(j, 10)+QString(":");
                qDebug()<<message<<cell_value;
            }
        }
    }
}

// 导出到excel
void Widget::on_pushButton_2_clicked()
{
    qDebug()<<"写Excel";
    QAxObject excel("Excel.Application");
    excel.setProperty("Visible", true);
    QAxObject *work_books = excel.querySubObject("WorkBooks");
    work_books->dynamicCall("Open(const QString&)", "D:/test.xlsx");
    excel.setProperty("Caption", "Qt Excel");
    QAxObject *work_book = excel.querySubObject("ActiveWorkBook");
    QAxObject *work_sheets = work_book->querySubObject("Sheets");  //Sheets也可换用WorkSheets

    //删除工作表（删除第一个）
    /*QAxObject *first_sheet = work_sheets->querySubObject("Item(int)", 1);
    first_sheet->dynamicCall("delete");*/

    int sheet_count = work_sheets->property("Count").toInt();  //获取工作表数目
    qDebug()<<"sheets count:"<<sheet_count;
    QAxObject *blast_sheet = work_sheets->querySubObject("Item(int)", sheet_count-1);
    QAxObject *last_sheet = work_sheets->querySubObject("Item(int)", sheet_count);
    qDebug()<<last_sheet->asVariant();

    QAxObject *work_sheet = work_sheets->querySubObject("Add(QVariant)", blast_sheet->asVariant());
    last_sheet->dynamicCall("Move(QVariant)", work_sheet->asVariant());

}
