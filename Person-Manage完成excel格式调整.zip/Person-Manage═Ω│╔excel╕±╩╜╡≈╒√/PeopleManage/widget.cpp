#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>
#include <QAxObject>
#include <QFileInfo>
#include <QDir>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowTitle("人事管理系统");
    setFixedSize(745,433);

    // 备份save.json文件
    dupJson();

    if (!level.loadGame()){

        /******************  写入日志 **********************/
        QString sname = "EXE start, but failed when load json";      // 程序初始化加载json数据库失败
        QString sinfo = "loadGame failed";
        mLog.log(sname, sinfo);
        /*************************************************/
    }

    /******************  写入日志 **********************/
    QString sname2 = QString("EXE start, then success when load json");  // 程序初始化加载json数据库成功
    QString sinfo2 = "loadGame success!";
    mLog.log(sname2, sinfo2);
    /*************************************************/

}

Widget::~Widget()
{
    delete ui;
}

// 添加按钮
void Widget::on_pushButton_clicked()
{
    /******************  写入日志 **********************/
    QString sname0 = "Add Button";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/
    Character firstOne;

    if(ui->lineEdit->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少姓名");
        return;
    }
    if(ui->lineEdit_3->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少身份证号");
        return;
    }
    if(ui->lineEdit_4->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少户口所在地");
        return;
    }
    if(ui->lineEdit_5->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少籍贯");
        return;
    }
    if(ui->lineEdit_6->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少联系电话");
        return;
    }
    if(ui->lineEdit_7->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少银行卡号");
        return;
    }
    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少员工编号");
        return;
    }
    if(ui->lineEdit_10->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少工龄");
        return;
    }

    QString Person_ID = ui->lineEdit_3->text();
    QString YuanGongID = ui->lineEdit_8->text();

    foreach (const Character npc, level.npcs()) {
        if (npc.Person_ID() == Person_ID){
            QMessageBox::about(NULL, "错误", "身份证号重复");
            return;
        }
    }
    foreach (const Character npc, level.npcs()) {
        if (npc.YuanGongID() == YuanGongID){
            QMessageBox::about(NULL, "错误", "员工编号重复");
            return;
        }
    }

    firstOne.setName(ui->lineEdit->text());
    firstOne.setGender(ui->comboBox->currentText());
    firstOne.setBirthDate(ui->dateEdit->dateTime().toString("yyyy-MM-dd"));
    firstOne.setPerson_ID(ui->lineEdit_3->text());
    firstOne.setXueli(ui->comboBox_2->currentText());
    firstOne.setHukou(ui->lineEdit_4->text());
    firstOne.setJiGuan(ui->lineEdit_5->text());
    firstOne.setPhoneNumber(ui->lineEdit_6->text());
    firstOne.setBankID(ui->lineEdit_7->text());

    firstOne.setYuanGongID(ui->lineEdit_8->text());
    firstOne.setBumen(ui->comboBox_3->currentText());
    firstOne.setZhiwei(ui->comboBox_4->currentText());
    firstOne.setRuzhiDate(ui->dateEdit_2->dateTime().toString("yyyy-MM-dd"));
    firstOne.setGongLin(ui->lineEdit_10->text());
    firstOne.setZhuangTai(ui->comboBox_5->currentText());
    firstOne.setBeizhu(ui->textEdit->toPlainText());

    level.appendCharacter(firstOne);

    if (!level.saveGame()){
        /******************  写入日志 **********************/
        QString sname = "Add success but failed when save to json";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        return;
    }

    /******************  写入日志 **********************/
    QString sname = "Add success and success when save to json";
    QString sinfo = firstOne.name() + " " + firstOne.gender() + " " + firstOne.BirthDate() + " " + firstOne.Person_ID() + " " + firstOne.Xueli() + " " + firstOne.Hukou() + " " + firstOne.JiGuan()
            + " " + firstOne.PhoneNumber() + " " + firstOne.BankID() + " " + firstOne.YuanGongID() + " " + firstOne.Bumen() + " " + firstOne.Zhiwei()
            + " " + firstOne.RuzhiDate() + " " + firstOne.GongLin() + " " + firstOne.ZhuangTai() + " " + firstOne.Beizhu();
    mLog.log(sname, sinfo);
    /*************************************************/

    QMessageBox::about(NULL, "提示", "添加成功");
}

// 修改按钮
void Widget::on_pushButton_2_clicked()
{
    bool if_existed = false;
    int index = 0;

    /******************  写入日志 **********************/
    QString sname0 = "Modify Button";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/

    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少修改用的员工编号");
        return;
    }
    QString YuanGongID = ui->lineEdit_8->text();
    foreach (const Character npc, level.npcs()) {
        if (npc.YuanGongID() == YuanGongID){
            if_existed = true;
            break;
        }
        index++;
    }

    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }else{
        if(ui->lineEdit->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少姓名");
            return;
        }
        if(ui->lineEdit_3->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少身份证号");
            return;
        }
        if(ui->lineEdit_4->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少户口所在地");
            return;
        }
        if(ui->lineEdit_5->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少籍贯");
            return;
        }
        if(ui->lineEdit_6->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少联系电话");
            return;
        }
        if(ui->lineEdit_7->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少银行卡号");
            return;
        }
        if(ui->lineEdit_10->text().isEmpty()){
            QMessageBox::about(NULL, "提示", "缺少工龄");
            return;
        }

        QString Person_ID = ui->lineEdit_3->text();
        foreach (const Character npc, level.npcs()) {
            if (npc.Person_ID() == Person_ID && npc.YuanGongID() != YuanGongID){
                QMessageBox::about(NULL, "错误", "身份证号与其他人重复");
                return;
            }
        }

        Character secOne;
        secOne.setName(ui->lineEdit->text());
        secOne.setGender(ui->comboBox->currentText());
        secOne.setBirthDate(ui->dateEdit->dateTime().toString("yyyy-MM-dd"));
        secOne.setPerson_ID(ui->lineEdit_3->text());
        secOne.setXueli(ui->comboBox_2->currentText());
        secOne.setHukou(ui->lineEdit_4->text());
        secOne.setJiGuan(ui->lineEdit_5->text());
        secOne.setPhoneNumber(ui->lineEdit_6->text());
        secOne.setBankID(ui->lineEdit_7->text());

        secOne.setYuanGongID(ui->lineEdit_8->text());
        secOne.setBumen(ui->comboBox_3->currentText());
        secOne.setZhiwei(ui->comboBox_4->currentText());
        secOne.setRuzhiDate(ui->dateEdit_2->dateTime().toString("yyyy-MM-dd"));
        secOne.setGongLin(ui->lineEdit_10->text());
        secOne.setZhuangTai(ui->comboBox_5->currentText());
        secOne.setBeizhu(ui->textEdit->toPlainText());

        level.updateCharacter(index, secOne);

        if (!level.saveGame()){
            /******************  写入日志 **********************/
            QString sname = "Modified success but failed when save to json";
            QString sinfo = "";
            mLog.log(sname, sinfo);
            /*************************************************/
            return;
        }

        /******************  写入日志 **********************/
        QString sname = "Modified success and success when save to json";
        QString sinfo = secOne.name() + " " + secOne.gender() + " " + secOne.BirthDate() + " " + secOne.Person_ID() + " " + secOne.Xueli() + " " + secOne.Hukou() + " " + secOne.JiGuan()
                        + " " + secOne.PhoneNumber() + " " + secOne.BankID() + " " + secOne.YuanGongID() + " " + secOne.Bumen() + " " + secOne.Zhiwei()
                        + " " + secOne.RuzhiDate() + " " + secOne.GongLin() + " " + secOne.ZhuangTai() + " " + secOne.Beizhu();
        mLog.log(sname, sinfo);
        /*************************************************/

        QMessageBox::about(NULL, "提示", "修改成功");
    }

}

// 查询按钮
void Widget::on_pushButton_3_clicked()
{
    /******************  写入日志 **********************/
    QString sname0 = "Query Button";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/

    QString YuanGongID;

    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少查询用的员工编号");
        return;
    }

    bool if_existed = false;
    YuanGongID = ui->lineEdit_8->text();

    foreach (const Character npc, level.npcs()) {
        if (npc.YuanGongID() == YuanGongID){
            if_existed = true;

            ui->lineEdit->setText(npc.name());
            ui->comboBox->setCurrentText(npc.gender());
            QString strBuffer = npc.BirthDate();
            ui->dateEdit->setDateTime(QDateTime::fromString(strBuffer, "yyyy-MM-dd"));
            ui->lineEdit_3->setText(npc.Person_ID());
            ui->comboBox_2->setCurrentText(npc.Xueli());
            ui->lineEdit_4->setText(npc.Hukou());
            ui->lineEdit_5->setText(npc.JiGuan());
            ui->lineEdit_6->setText(npc.PhoneNumber());
            ui->lineEdit_7->setText(npc.BankID());
            ui->lineEdit_8->setText(npc.YuanGongID());
            ui->comboBox_3->setCurrentText(npc.Bumen());
            ui->comboBox_4->setCurrentText(npc.Zhiwei());
            strBuffer = npc.RuzhiDate();
            ui->dateEdit_2->setDateTime(QDateTime::fromString(strBuffer, "yyyy-MM-dd"));
            ui->lineEdit_10->setText(npc.GongLin());
            ui->comboBox_5->setCurrentText(npc.ZhuangTai());
            ui->textEdit->setPlainText(npc.Beizhu());
        }
    }

    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }

    loadImage(YuanGongID);

    /******************  写入日志 **********************/
    QString sname = "Query success";
    QString sinfo = ui->lineEdit->text() + " " + ui->comboBox->currentText() + " " + ui->dateEdit->dateTime().toString("yyyy-MM-dd")
            + " " + ui->lineEdit_3->text() + " " + ui->comboBox_2->currentText() + " " + ui->lineEdit_4->text() + " " + ui->lineEdit_5->text()
            + " " + ui->lineEdit_6->text() + " " + ui->lineEdit_7->text() + " " + ui->lineEdit_8->text() + " " + ui->comboBox_3->currentText()
            + " " + ui->comboBox_4->currentText() + " " + ui->dateEdit_2->dateTime().toString("yyyy-MM-dd") + " " + ui->lineEdit_10->text()
            + " " + ui->comboBox_5->currentText() + " " + ui->textEdit->toPlainText();
    mLog.log(sname, sinfo);
    /*************************************************/

    QMessageBox::about(NULL, "提示", "查询成功");
}

// 删除按钮
void Widget::on_pushButton_4_clicked()
{
    bool if_existed = false;
    int index = 0;

    /******************  写入日志 **********************/
    QString sname0 = "Delete Button";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/

    if(ui->lineEdit_8->text().isEmpty()){
        QMessageBox::about(NULL, "提示", "缺少删除用的员工编号");
        return;
    }

    QString YuanGongID = ui->lineEdit_8->text();
    foreach (const Character npc, level.npcs()) {
        if (npc.YuanGongID() == YuanGongID){
            if_existed = true;
            break;
        }
        index++;
    }
    if (if_existed == false){
        QMessageBox::about(NULL, "提示", "没有这个员工");
        return;
    }else{

        /******************  写入日志 **********************/
        QString sname = "Delete success";
        Character firstOne = level.npcs().at(index);
        QString sinfo = firstOne.name() + " " + firstOne.gender() + " " + firstOne.BirthDate() + " " + firstOne.Person_ID() + " " + firstOne.Xueli() + " " + firstOne.Hukou() + " " + firstOne.JiGuan()
                + " " + firstOne.PhoneNumber() + " " + firstOne.BankID() + " " + firstOne.YuanGongID() + " " + firstOne.Bumen() + " " + firstOne.Zhiwei()
                + " " + firstOne.RuzhiDate() + " " + firstOne.GongLin() + " " + firstOne.ZhuangTai() + " " + firstOne.Beizhu();
        mLog.log(sname, sinfo);
        /*************************************************/

        level.deleteCharacter(index);

        if (!level.saveGame()){
            /******************  写入日志 **********************/
            QString sname = "Delete success but failed when save to json";
            QString sinfo = "";
            mLog.log(sname, sinfo);
            /*************************************************/
            return;
        }

        ui->lineEdit->setText("");
        ui->lineEdit_3->setText("");
        ui->lineEdit_4->setText("");
        ui->lineEdit_5->setText("");
        ui->lineEdit_6->setText("");
        ui->lineEdit_7->setText("");
        //ui->lineEdit_8->setText("");    // 编号不清空
        ui->lineEdit_10->setText("");
        ui->textEdit->setPlainText("");

        QMessageBox::about(NULL, "提示", "删除成功");
    }
}

//清空按钮
void Widget::on_pushButton_5_clicked()
{
    /******************  写入日志 **********************/
    QString sname0 = "Empty Button";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/
    ui->lineEdit->setText("");
    ui->lineEdit_3->setText("");
    ui->lineEdit_4->setText("");
    ui->lineEdit_5->setText("");
    ui->lineEdit_6->setText("");
    ui->lineEdit_7->setText("");
    ui->lineEdit_8->setText("");
    ui->lineEdit_10->setText("");
    ui->textEdit->setPlainText("");

    /******************  写入日志 **********************/
    QString sname = "Empty Success";
    QString sinfo = "";
    mLog.log(sname, sinfo);
    /*************************************************/

    QMessageBox::about(NULL, "提示", "清空成功");
}

// 从excel导入
void Widget::on_pushButton_10_clicked()
{
    /******************  写入日志 **********************/
    QString sname0 = "Read from excel";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/

    // 备份导入前的json文件
    dupJsonBeforeReadExcel();
    QAxObject *excel = new QAxObject("Excel.Application");
    if (excel==NULL) {
        /******************  写入日志 **********************/
        QString sname = "EXCEL READ new excel application failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜");
        return;
    }
    excel->setProperty("Visible", false);
    excel->setProperty("DisplayAlerts", false);
    QAxObject * workbooks = excel->querySubObject("WorkBooks");
    if (workbooks==NULL) 	{
        /******************  写入日志 **********************/
        QString sname = "EXCEL READ get WorkBooks failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜");
        return;
    }

    QString excelpath = QDir::currentPath();
    excelpath = excelpath + QString("/test.xlsx");
    excelpath.replace("/", "\\");

    QFileInfo fi(excelpath);
    if(!fi.exists()){
        QMessageBox::about(NULL, "出错", "test.xlsx\344\270\215\345\255\230\345\234\250");
        return;
    }

    workbooks->dynamicCall("Open (const QString&)", excelpath);

    QAxObject * workbook = excel->querySubObject("ActiveWorkBook");
    if (workbook==NULL) 	{
        /******************  写入日志 **********************/
        QString sname = "EXCEL READ get ActiveWorkBook failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜");
        return;
    }
    QAxObject * workSheet = workbook->querySubObject("Worksheets(int)",1);
    if (workSheet==NULL) 	{
        /******************  写入日志 **********************/
        QString sname = "EXCEL READ get sheet one failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜");
        return;
    }

    QAxObject *used_range = workSheet->querySubObject("UsedRange");
    QVariant var = used_range->dynamicCall("Value");

    /*********************************************/
    QList<QList<QVariant>> res;
    QVariantList varRows = var.toList();
    if(varRows.isEmpty())
    {
        /******************  写入日志 **********************/
        QString sname = "EXCEL READ varRow is empty";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "\345\260\206\350\246\201\345\257\274\345\205\245\347\232\204EXCEL\344\270\272\347\251\272\357\274\214\350\257\267\344\277\235\350\257\201EXCEL\346\234\211\345\200\274");          // 将要导入的EXCEL为空，请保证EXCEL有值
        return;
    }
    const int rowCount = varRows.size();
    QVariantList rowData;
    for(int i=0;i<rowCount;++i)
    {
        rowData = varRows[i].toList();
        res.push_back(rowData);
    }
    /*********************************************/

    /********************************************************** 打印读入的内容
    int count = 0;
    qDebug()<<"---------------------------------------------";
    foreach (const QList<QVariant> npc, res) {
        foreach(const QVariant sub, npc){
            qDebug()<<count<<sub.toString();
        }
        count++;
    }
    qDebug()<<"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%";
    ************************************************************/

    level.clearList();
    /******************  写入日志 **********************/
    QString sname = "EXCEL READ clear level.list";
    QString sinfo = "";
    mLog.log(sname, sinfo);
    /*************************************************/


    int index = 0;
    foreach (const QList<QVariant> irow, res) {
        if(index < 2){
            index++;
            continue;
        }
        Character tempOne;
        int baseindex = 1;
        tempOne.setName(irow.at(baseindex+0).toString());
        tempOne.setGender(irow.at(baseindex+1).toString());
        tempOne.setBirthDate(irow.at(baseindex+2).toDateTime().toString("yyyy-MM-dd"));
        tempOne.setPerson_ID(irow.at(baseindex+3).toString());
        tempOne.setXueli(irow.at(baseindex+4).toString());
        tempOne.setHukou(irow.at(baseindex+5).toString());
        tempOne.setJiGuan(irow.at(baseindex+6).toString());
        tempOne.setPhoneNumber(irow.at(baseindex+7).toString());
        tempOne.setBankID(irow.at(baseindex+8).toString());
        tempOne.setYuanGongID(irow.at(baseindex+9).toString());
        tempOne.setBumen(irow.at(baseindex+10).toString());
        tempOne.setZhiwei(irow.at(baseindex+11).toString());
        tempOne.setRuzhiDate(irow.at(baseindex+12).toDateTime().toString("yyyy-MM-dd"));
        tempOne.setGongLin(irow.at(baseindex+13).toString());
        tempOne.setZhuangTai(irow.at(baseindex+14).toString());
        tempOne.setBeizhu(irow.at(baseindex+15).toString());
        level.appendCharacter(tempOne);
    }

    workbook->dynamicCall("Close()");//关闭工作簿
    excel->dynamicCall("Quit()");//关闭excel
    delete excel;
    excel=NULL;

    /******************  写入日志 **********************/
    QString sname2 = "EXCEL READ excel application quit!";
    QString sinfo2 = "";
    mLog.log(sname2, sinfo2);
    /*************************************************/


    QMessageBox::about(NULL, "提示", "读入excel成功");
}

// 导出到excel
void Widget::on_pushButton_11_clicked()
{
    /******************  写入日志 **********************/
    QString sname0 = "Write to Excel";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/

    QAxObject *excel = new QAxObject("Excel.Application");
    if (excel==NULL) {
        /******************  写入日志 **********************/
        QString sname = "EXCEL WRITE new excel application failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜w1");
        return;
    }
    excel->setProperty("Visible", false);
    excel->setProperty("DisplayAlerts", false);
    QAxObject * workbooks = excel->querySubObject("WorkBooks");
    if (workbooks==NULL) 	{
        /******************  写入日志 **********************/
        QString sname = "EXCEL WRITE get WorkBooks failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜w2");
        return;
    }
    workbooks->dynamicCall("Add");
    QAxObject * workbook = excel->querySubObject("ActiveWorkBook");
    if (workbook==NULL) 	{
        /******************  写入日志 **********************/
        QString sname = "EXCEL WRITE get ActiveWorkBook failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜w3");
        return;
    }
    QAxObject * workSheet = workbook->querySubObject("Worksheets(int)",1);
    if (workSheet==NULL) 	{
        /******************  写入日志 **********************/
        QString sname = "EXCEL WRITE get sheet one failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜w4");
        return;
    }

    level.sortmNpcs();

    QVariantList varlist;

    QVariantList oneLine;
    oneLine.append(QVariant("\345\261\271 \345\256\217 \351\236\213 \344\270\232 \345\221\230 \345\267\245 \350\212\261 \345\220\215 \345\206\214"));  // 屹宏鞋业员工花名册
    int i;
    for(i=1; i<17; ++i){
        oneLine.append(QVariant("1"));
    }

    varlist.append(QVariant(oneLine));

    QVariantList titleLine;
    titleLine.append(QVariant("\345\272\217\345\217\267"));    // 序号
    titleLine.append(QVariant("\351\203\250\351\227\250"));       // 部门
    titleLine.append(QVariant("\345\221\230\345\267\245\347\274\226\345\217\267"));    // 员工编号
    titleLine.append(QVariant("\345\247\223\345\220\215"));  // 姓名
    titleLine.append(QVariant("\346\200\247\345\210\253"));             // 性别
    titleLine.append(QVariant("\345\207\272\347\224\237\346\227\245\346\234\237"));   //出生日期
    titleLine.append(QVariant("\350\272\253\344\273\275\350\257\201\345\217\267"));   // 身份证号
    titleLine.append(QVariant("\345\234\260\345\235\200"));  //户口所在地，地址
    titleLine.append(QVariant("\347\216\260\345\261\205\345\234\260"));       // 籍贯,现居地
    titleLine.append(QVariant("\345\255\246\345\216\206"));      //学历
    titleLine.append(QVariant("\350\201\224\347\263\273\347\224\265\350\257\235"));    // 联系电话
    titleLine.append(QVariant("\351\223\266\350\241\214\345\215\241"));      // 银行卡
    titleLine.append(QVariant("\345\262\227\344\275\215"));       // 岗位，也就是职位
    titleLine.append(QVariant("\345\205\245\350\201\214\346\227\245\346\234\237"));    // 入职日期
    titleLine.append(QVariant("\345\267\245\351\276\204"));       // 工龄
    titleLine.append(QVariant("\347\212\266\346\200\201"));       // 状态
    titleLine.append(QVariant("\345\244\207\346\263\250"));       // 备注

    // 添加标题
    varlist.append(QVariant(titleLine));

    QList<Character> mNpcs = level.npcs();
    int rows = mNpcs.size();
    for(int i=0; i<rows; ++i)
    {
        QVariantList eachrow;

        eachrow.append(i+1);
        eachrow.append(mNpcs[i].Bumen());
        eachrow.append(mNpcs[i].YuanGongID());
        eachrow.append(mNpcs[i].name());
        eachrow.append(mNpcs[i].gender());
        eachrow.append(mNpcs[i].BirthDate());
        eachrow.append(mNpcs[i].Person_ID());
        eachrow.append(mNpcs[i].Hukou());
        eachrow.append(mNpcs[i].JiGuan());
        eachrow.append(mNpcs[i].Xueli());
        eachrow.append(mNpcs[i].PhoneNumber());
        eachrow.append(mNpcs[i].BankID());
        eachrow.append(mNpcs[i].Zhiwei());
        eachrow.append(mNpcs[i].RuzhiDate());
        eachrow.append(mNpcs[i].GongLin());
        eachrow.append(mNpcs[i].ZhuangTai());
        eachrow.append(mNpcs[i].Beizhu());

        varlist.append(QVariant(eachrow));
    }

    QVariant vars = QVariant(varlist);

    // 第七列 身份证号
    QString columnName_7 = "G:G";
    QAxObject * colObject_7 = workSheet->querySubObject("Columns(const QString&)", columnName_7);
    if (colObject_7==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_7请关闭软件并联系陈胜");
        return;
    }
    colObject_7->setProperty("ColumnWidth", 20);
    colObject_7->setProperty("NumberFormatLocal", "@");

    // 第12列 银行卡号
    QString columnName_12 = "L:L";
    QAxObject * colObject_12 = workSheet->querySubObject("Columns(const QString&)", columnName_12);
    if (colObject_12==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_12请关闭软件并联系陈胜");
        return;
    }
    colObject_12->setProperty("ColumnWidth", 21);
    colObject_12->setProperty("NumberFormatLocal", "@");

    // 将数据写入excel
    QString rangStr = "A1:Q";
    rangStr += QString::number(rows+2);      // 有一行标题栏
    QAxObject *range = workSheet->querySubObject("Range(const QString&)",rangStr);
    if (range==NULL) 	{
        /******************  写入日志 **********************/
        QString sname = "EXCEL WRITE get usedRange one failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜w5");
        return;
    }
    // 设置单元格格式为文本
    //range->setProperty("NumberFormatLocal", "@");  // 设置为文本

    bool succ = false;
    succ = range->setProperty("Value", vars);
    if (!succ){
        /******************  写入日志 **********************/
        QString sname = "EXCEL WRITE write usedRange failed";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        QMessageBox::about(NULL, "出错", "请关闭软件并联系陈胜w6");
        return;
    }
    range->setProperty("RowHeight", 25);
    range->setProperty("HorizontalAlignment", -4108);
    range->setProperty("VerticalAlignment", -4108);

    // 第一列 序号
    QString columnName_1 = "A:A";
    QAxObject * colObject_1 = workSheet->querySubObject("Columns(const QString&)", columnName_1);
    if (colObject_1==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_1请关闭软件并联系陈胜");
        return;
    }
    colObject_1->setProperty("ColumnWidth", 5);

    // 第二列 部门
    QString columnName_2 = "B:B";
    QAxObject * colObject_2 = workSheet->querySubObject("Columns(const QString&)", columnName_2);
    if (colObject_2==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_2请关闭软件并联系陈胜");
        return;
    }
    colObject_2->setProperty("ColumnWidth", 11);

    // 第三列 员工编号
    QString columnName_3 = "C:C";
    QAxObject * colObject_3 = workSheet->querySubObject("Columns(const QString&)", columnName_3);
    if (colObject_3==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_3请关闭软件并联系陈胜");
        return;
    }
    colObject_3->setProperty("ColumnWidth", 9);

    // 第四列 姓名
    QString columnName_4 = "D:D";
    QAxObject * colObject_4 = workSheet->querySubObject("Columns(const QString&)", columnName_4);
    if (colObject_4==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_4请关闭软件并联系陈胜");
        return;
    }
    colObject_4->setProperty("ColumnWidth", 10);

    // 第五列 性别
    QString columnName_5 = "E:E";
    QAxObject * colObject_5 = workSheet->querySubObject("Columns(const QString&)", columnName_5);
    if (colObject_5==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_5请关闭软件并联系陈胜");
        return;
    }
    colObject_5->setProperty("ColumnWidth", 5);

    // 第六列 出生日期
    QString columnName_6 = "F:F";
    QAxObject * colObject_6 = workSheet->querySubObject("Columns(const QString&)", columnName_6);
    if (colObject_6==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_6请关闭软件并联系陈胜");
        return;
    }
    colObject_6->setProperty("ColumnWidth", 11);

    // 第八列 地址
    QString columnName_8 = "H:H";
    QAxObject * colObject_8 = workSheet->querySubObject("Columns(const QString&)", columnName_8);
    if (colObject_8==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_6请关闭软件并联系陈胜");
        return;
    }
    colObject_8->setProperty("ColumnWidth", 30);

    // 第9列 现居地
    QString columnName_9 = "I:I";
    QAxObject * colObject_9 = workSheet->querySubObject("Columns(const QString&)", columnName_9);
    if (colObject_9==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_9请关闭软件并联系陈胜");
        return;
    }
    colObject_9->setProperty("ColumnWidth", 14);

    // 第10列 学历
    QString columnName_10 = "J:J";
    QAxObject * colObject_10 = workSheet->querySubObject("Columns(const QString&)", columnName_10);
    if (colObject_10==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_10请关闭软件并联系陈胜");
        return;
    }
    colObject_10->setProperty("ColumnWidth", 5);

    // 第11列 联系电话
    QString columnName_11 = "K:K";
    QAxObject * colObject_11 = workSheet->querySubObject("Columns(const QString&)", columnName_11);
    if (colObject_11==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_11请关闭软件并联系陈胜");
        return;
    }
    colObject_11->setProperty("ColumnWidth", 13);

    // 第13列 岗位
    QString columnName_13 = "M:M";
    QAxObject * colObject_13 = workSheet->querySubObject("Columns(const QString&)", columnName_13);
    if (colObject_13==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_13请关闭软件并联系陈胜");
        return;
    }
    colObject_13->setProperty("ColumnWidth", 10);

    // 第14列 入职日期
    QString columnName_14 = "N:N";
    QAxObject * colObject_14 = workSheet->querySubObject("Columns(const QString&)", columnName_14);
    if (colObject_14==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_14请关闭软件并联系陈胜");
        return;
    }
    colObject_14->setProperty("ColumnWidth", 11);

    // 第15列 工龄
    QString columnName_15 = "O:O";
    QAxObject * colObject_15 = workSheet->querySubObject("Columns(const QString&)", columnName_15);
    if (colObject_15==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_15请关闭软件并联系陈胜");
        return;
    }
    colObject_15->setProperty("ColumnWidth", 5);

    // 第16列 状态
    QString columnName_16 = "P:P";
    QAxObject * colObject_16 = workSheet->querySubObject("Columns(const QString&)", columnName_16);
    if (colObject_16==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_16请关闭软件并联系陈胜");
        return;
    }
    colObject_16->setProperty("ColumnWidth", 6);

    // 第17列 备注
    QString columnName_17 = "Q:Q";
    QAxObject * colObject_17 = workSheet->querySubObject("Columns(const QString&)", columnName_17);
    if (colObject_17==NULL) 	{
        QMessageBox::about(NULL, "出错", "colObject_17请关闭软件并联系陈胜");
        return;
    }
    colObject_17->setProperty("ColumnWidth", 20);

    // 设置标题行字体加粗
    QString rowsName_2 = "2:2";
    QAxObject * rowsObject_2 = workSheet->querySubObject("Rows(const QString &)", rowsName_2);
    QAxObject *rowFont_2 = rowsObject_2->querySubObject("Font");  //获取单元格字体
    rowFont_2->setProperty("Bold", true);  //设置单元格字体加粗

    // 合并单元格,制作大标题
    QString merge_cell = "A1:Q1";
    QAxObject *merge_range = workSheet->querySubObject("Range(const QString&)", merge_cell);
    merge_range->setProperty("HorizontalAlignment", -4108);
    merge_range->setProperty("VerticalAlignment", -4108);
    merge_range->setProperty("MergeCells", true);  //合并单元格
    merge_range->setProperty("RowHeight", 40);

    QAxObject *fontMerge = merge_range->querySubObject("Font");  //获取单元格字体
    fontMerge->setProperty("Bold", true);  //设置单元格字体加粗
    fontMerge->setProperty("Size", 20);  //设置单元格字体大小


    QString excelpath = QDir::currentPath();
    //excelpath = excelpath + QString("/test2.xlsx");
    excelpath = excelpath + QString("/\345\261\271\345\256\217\351\236\213\344\270\232\345\221\230\345\267\245\350\212\261\345\220\215\345\206\214.xlsx");

    excelpath.replace("/", "\\");

    workbook->dynamicCall("SaveAs(const QString&)", excelpath);

    workbook->dynamicCall("Close(Boolean)", false);  //关闭文件
    excel->dynamicCall("Quit(void)");  //退出
    delete excel;
    excel = NULL;

    /******************  写入日志 **********************/
    QString sname = "EXCEL WRITE excel application quit!";
    QString sinfo = "";
    mLog.log(sname, sinfo);
    /*************************************************/

    QMessageBox::about(NULL, "提示", "写入excel成功");
}

void Widget::setColumn(int columnNumber, int columnWidth, int columnFormat){
    QString selStr;
    selStr.append(QChar(columnNumber - 1 + 'A'));
    selStr.append(":");
    selStr.append(QChar(columnNumber - 1 + 'A'));
    qDebug()<<"column:"<<columnNumber;

}

void Widget::closeEvent(QCloseEvent *event)
{
    //窗口关闭之前需要的操作~
    /******************  写入日志 **********************/
    QString sname0 = "Close Operation";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/

    if (!level.saveGame()){
        /******************  写入日志 **********************/
        QString sname = "Close but failed when save to json";
        QString sinfo = "";
        mLog.log(sname, sinfo);
        /*************************************************/
        return;
    }

    /******************  写入日志 **********************/
    QString sname = "Close and success when save to json";
    QString sinfo = "";
    mLog.log(sname, sinfo);
    /*************************************************/
}

// 退出按钮
void Widget::on_pushButton_6_clicked()
{
    /******************  写入日志 **********************/
    QString sname0 = "\351\200\200\345\207\272\346\214\211\351\222\256";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/
    this->close();
}

// 备份json文件
void Widget::on_pushButton_12_clicked()
{
    /******************  写入日志 **********************/
    QString sname0 = "备份json按钮";
    QString sinfo0 = "";
    mLog.log(sname0, sinfo0);
    /*************************************************/

    dupJson();
    //dupJsonBeforeReadExcel();

    QMessageBox::about(NULL, "提示", "备份json成功");
}

void Widget::dupJson(){
    QFile jsonFile(QStringLiteral("save.json"));
    QFile backjsonFile(QStringLiteral(".\\data\\save_back.json"));

    if (!jsonFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        /******************  写入日志 **********************/
        QString sname0 = "dupJson: open save.json file failed";
        QString sinfo0 = "";
        mLog.log(sname0, sinfo0);
        /*************************************************/
        return;
    }

    if (!backjsonFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        /******************  写入日志 **********************/
        QString sname0 = "dupJson: open backsave.json file failed";
        QString sinfo0 = "";
        mLog.log(sname0, sinfo0);
        /*************************************************/
        return;
    }
    QByteArray bytes = jsonFile.readAll();
    backjsonFile.write(bytes);

    jsonFile.close();
    backjsonFile.close();

    /******************  写入日志 **********************/
    QString sname = "duplicate save.json";
    QString sinfo = "";
    mLog.log(sname, sinfo);
    /*************************************************/
}

void Widget::dupJsonBeforeReadExcel(){
    QFile jsonFile(QStringLiteral("save.json"));
    QString filename = ".\\data\\save_before_excel_";
    QDateTime time = QDateTime::currentDateTime();//获取系统现在的时间
    QString str = time.toString("yyyy-MM-dd-hh-mm-ss"); //设置显示格式
    filename = filename + str + ".json";

    QFile backjsonFile(filename);

    if (!jsonFile.open(QIODevice::ReadOnly | QIODevice::Text)) {

        /******************  写入日志 **********************/
        QString sname0 = "dupJsonBeforeReadExcel: open save.json file failed";
        QString sinfo0 = "";
        mLog.log(sname0, sinfo0);
        /*************************************************/
        return;
    }

    if (!backjsonFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {

        /******************  写入日志 **********************/
        QString sname0 = "dupJsonBeforeReadExcel: open backsave.json file failed";
        QString sinfo0 = "";
        mLog.log(sname0, sinfo0);
        /*************************************************/
        return;
    }
    QByteArray bytes = jsonFile.readAll();
    backjsonFile.write(bytes);

    jsonFile.close();
    backjsonFile.close();

    /******************  写入日志 **********************/
    QString sname = "duplicate save.json before reading excel";
    QString sinfo = "";
    mLog.log(sname, sinfo);
    /*************************************************/
}

void Widget::loadImage(QString imagename){
    //qDebug()<<"加载图片";
    QString path = QString(".\\images\\") + imagename;  //  + QString(".jpg")
    QString pandunpath = path + QString(".jpg");
    QFileInfo fi(pandunpath);
    if(!fi.exists()){
        pandunpath = path + QString(".png");
        QFileInfo fi2(pandunpath);
        if(!fi2.exists()){
            pandunpath = path + QString(".bmp");
        }
    }

    qDebug()<<pandunpath;

    QPixmap px;
    px.load(pandunpath);
    ui->label_10->setPixmap(px);

    ui->label_10->setScaledContents(true);
    ui->label_10->setScaledContents(true);
    ui->label_10->setVisible(true);
}

// 显示内容
void Widget::on_pushButton_13_clicked()
{
    qDebug()<<"显示内容按钮";
    foreach (const Character npc, level.npcs()) {
        qDebug()<<index<<"  -----------------------------------";
        qDebug()<<npc.name();
        qDebug()<<npc.gender();
        qDebug()<<npc.BirthDate();
        qDebug()<<npc.Person_ID();
        qDebug()<<npc.Xueli();
        qDebug()<<npc.Hukou();
        qDebug()<<npc.JiGuan();
        qDebug()<<npc.PhoneNumber();
        qDebug()<<npc.BankID();
        qDebug()<<npc.YuanGongID();
        qDebug()<<npc.Bumen();
        qDebug()<<npc.Zhiwei();
        qDebug()<<npc.RuzhiDate();
        qDebug()<<npc.GongLin();
        qDebug()<<npc.ZhuangTai();
        qDebug()<<npc.Beizhu();
        index++;
    }
}
