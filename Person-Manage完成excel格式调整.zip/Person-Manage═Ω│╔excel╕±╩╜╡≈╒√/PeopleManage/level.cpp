/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "level.h"

#include <QJsonArray>
#include <QDebug>
#include <QJsonDocument>

Level::Level() {
}

const QList<Character> &Level::npcs() const
{
    return mNpcs;
}

void Level::setNpcs(const QList<Character> &npcs)
{
    mNpcs = npcs;
}

void Level::appendCharacter(const Character &character){
    mNpcs.append(character);
}

void Level::updateCharacter(int index, const Character &character){
    mNpcs.removeAt(index);
    mNpcs.insert(index, character);
}

void Level::deleteCharacter(int index){
    mNpcs.removeAt(index);
}

void Level::clearList(){
    mNpcs.clear();
}

bool Level::loadGame()
{
    /******************  写入日志 **********************/
    QString sname = "In level loadGame";
    QString sinfo = "loadGame process...";
    mLog.log(sname, sinfo);
    /*************************************************/

    QFile loadFile(QStringLiteral("save.json"));

    if (!loadFile.open(QIODevice::ReadOnly)) {
        /******************  写入日志 **********************/
        QString sname2 = "In level loadGame";
        QString sinfo2 = "open save.json failed";
        mLog.log(sname2, sinfo2);
        /*************************************************/

        return false;
    }

    QByteArray saveData = loadFile.readAll();

    QJsonDocument loadDoc(QJsonDocument::fromJson(saveData));

    read(loadDoc.object());

    /******************  写入日志 **********************/
    QString sname3 = "In level loadGame";
    QString sinfo3 = "loadGame end...";
    mLog.log(sname3, sinfo3);
    /*************************************************/

    return true;
}
//! [3]

//! [4]
bool Level::saveGame()
{
    /******************  写入日志 **********************/
    QString sname = "In level saveGame";
    QString sinfo = "saveGame process...";
    mLog.log(sname, sinfo);
    /*************************************************/


    // 存入前排序
    sortmNpcs();

    QFile saveFile(QStringLiteral("save.json"));

    if (!saveFile.open(QIODevice::WriteOnly)) {
        /******************  写入日志 **********************/
        QString sname2 = "In level saveGame";
        QString sinfo2 = "save save.json failed";
        mLog.log(sname2, sinfo2);
        /*************************************************/

        return false;
    }

    QJsonObject gameObject;
    write(gameObject);
    QJsonDocument saveDoc(gameObject);
    saveFile.write(saveDoc.toJson());

    /******************  写入日志 **********************/
    QString sname3 = "In level saveGame";
    QString sinfo3 = "saveGame end...";
    mLog.log(sname3, sinfo3);
    /*************************************************/

    return true;
}

//! [0]
void Level::read(const QJsonObject &json)
{
    mNpcs.clear();
    QJsonArray npcArray = json["npcs"].toArray();
    for (int npcIndex = 0; npcIndex < npcArray.size(); ++npcIndex) {
        QJsonObject npcObject = npcArray[npcIndex].toObject();
        Character npc;
        npc.read(npcObject);
        mNpcs.append(npc);
    }
}
//! [0]

//! [1]
void Level::write(QJsonObject &json) const
{
    QJsonArray npcArray;
    foreach (const Character npc, mNpcs) {
        QJsonObject npcObject;
        npc.write(npcObject);
        npcArray.append(npcObject);
    }
    json["npcs"] = npcArray;
}
//! [1]

bool compareCharacterData(const Character &barAmount1, const Character &barAmount2)
{
    if (barAmount1.YuanGongID() < barAmount2.YuanGongID())
    {
        return true;
    }
    return false;
}

void Level::sortmNpcs(){

    // 对文件按时间排序
    qSort(mNpcs.begin(), mNpcs.end(), compareCharacterData);

    /******************  写入日志 **********************/
    QString sname = "In level sortmNpcs";
    QString sinfo = "sort level list";
    mLog.log(sname, sinfo);
    /*************************************************/

}
