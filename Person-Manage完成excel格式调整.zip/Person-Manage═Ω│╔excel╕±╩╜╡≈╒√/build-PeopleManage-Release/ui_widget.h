/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGroupBox *groupBox;
    QLabel *label;
    QLineEdit *lineEdit;
    QComboBox *comboBox;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QLabel *label_5;
    QComboBox *comboBox_2;
    QLabel *label_6;
    QLineEdit *lineEdit_4;
    QLabel *label_7;
    QLineEdit *lineEdit_5;
    QLabel *label_8;
    QLineEdit *lineEdit_6;
    QLabel *label_9;
    QLineEdit *lineEdit_7;
    QLabel *label_10;
    QDateEdit *dateEdit;
    QGroupBox *groupBox_2;
    QLabel *label_11;
    QLineEdit *lineEdit_8;
    QLabel *label_12;
    QComboBox *comboBox_3;
    QLabel *label_13;
    QComboBox *comboBox_4;
    QLabel *label_14;
    QLabel *label_15;
    QLineEdit *lineEdit_10;
    QLabel *label_16;
    QComboBox *comboBox_5;
    QTextEdit *textEdit;
    QLabel *label_17;
    QDateEdit *dateEdit_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_10;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(745, 438);
        groupBox = new QGroupBox(Widget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(0, 20, 351, 401));
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 30, 24, 16));
        lineEdit = new QLineEdit(groupBox);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(90, 30, 108, 20));
        comboBox = new QComboBox(groupBox);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(90, 70, 69, 20));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 70, 24, 16));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(20, 110, 48, 12));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(20, 150, 54, 12));
        lineEdit_3 = new QLineEdit(groupBox);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(90, 150, 231, 20));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(20, 190, 54, 12));
        comboBox_2 = new QComboBox(groupBox);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(90, 190, 69, 20));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(20, 230, 61, 16));
        lineEdit_4 = new QLineEdit(groupBox);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(90, 230, 231, 20));
        label_7 = new QLabel(groupBox);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(20, 270, 61, 16));
        lineEdit_5 = new QLineEdit(groupBox);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(90, 270, 221, 20));
        label_8 = new QLabel(groupBox);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(20, 310, 61, 16));
        lineEdit_6 = new QLineEdit(groupBox);
        lineEdit_6->setObjectName(QStringLiteral("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(90, 310, 221, 20));
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(20, 350, 61, 16));
        lineEdit_7 = new QLineEdit(groupBox);
        lineEdit_7->setObjectName(QStringLiteral("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(90, 350, 221, 20));
        label_10 = new QLabel(groupBox);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(220, 20, 101, 111));
        label_10->setFrameShape(QFrame::Panel);
        label_10->setFrameShadow(QFrame::Raised);
        dateEdit = new QDateEdit(groupBox);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(90, 110, 111, 22));
        groupBox_2 = new QGroupBox(Widget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(370, 20, 241, 401));
        label_11 = new QLabel(groupBox_2);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(20, 30, 54, 12));
        lineEdit_8 = new QLineEdit(groupBox_2);
        lineEdit_8->setObjectName(QStringLiteral("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(110, 20, 113, 20));
        label_12 = new QLabel(groupBox_2);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(20, 70, 54, 12));
        comboBox_3 = new QComboBox(groupBox_2);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(110, 60, 111, 22));
        label_13 = new QLabel(groupBox_2);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(20, 110, 71, 20));
        comboBox_4 = new QComboBox(groupBox_2);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        comboBox_4->setGeometry(QRect(110, 110, 111, 22));
        label_14 = new QLabel(groupBox_2);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(20, 150, 71, 20));
        label_15 = new QLabel(groupBox_2);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(20, 190, 71, 20));
        lineEdit_10 = new QLineEdit(groupBox_2);
        lineEdit_10->setObjectName(QStringLiteral("lineEdit_10"));
        lineEdit_10->setGeometry(QRect(110, 190, 113, 20));
        label_16 = new QLabel(groupBox_2);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(20, 230, 71, 20));
        comboBox_5 = new QComboBox(groupBox_2);
        comboBox_5->setObjectName(QStringLiteral("comboBox_5"));
        comboBox_5->setGeometry(QRect(110, 230, 69, 22));
        textEdit = new QTextEdit(groupBox_2);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(20, 290, 211, 101));
        label_17 = new QLabel(groupBox_2);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(20, 270, 54, 12));
        dateEdit_2 = new QDateEdit(groupBox_2);
        dateEdit_2->setObjectName(QStringLiteral("dateEdit_2"));
        dateEdit_2->setGeometry(QRect(110, 150, 111, 22));
        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(650, 10, 75, 31));
        pushButton_2 = new QPushButton(Widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(650, 50, 75, 31));
        pushButton_3 = new QPushButton(Widget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(650, 90, 75, 31));
        pushButton_4 = new QPushButton(Widget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(650, 130, 75, 31));
        pushButton_5 = new QPushButton(Widget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(650, 170, 75, 31));
        pushButton_6 = new QPushButton(Widget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(650, 210, 75, 31));
        pushButton_10 = new QPushButton(Widget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(650, 250, 81, 31));
        pushButton_11 = new QPushButton(Widget);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(650, 290, 81, 31));
        pushButton_12 = new QPushButton(Widget);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(650, 330, 81, 31));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("Widget", "\345\237\272\346\234\254\344\277\241\346\201\257", Q_NULLPTR));
        label->setText(QApplication::translate("Widget", "\345\247\223\345\220\215", Q_NULLPTR));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("Widget", "\347\224\267", Q_NULLPTR)
         << QApplication::translate("Widget", "\345\245\263", Q_NULLPTR)
        );
        label_2->setText(QApplication::translate("Widget", "\346\200\247\345\210\253", Q_NULLPTR));
        label_3->setText(QApplication::translate("Widget", "\345\207\272\347\224\237\346\227\245\346\234\237", Q_NULLPTR));
        label_4->setText(QApplication::translate("Widget", "\350\272\253\344\273\275\350\257\201\345\217\267", Q_NULLPTR));
        label_5->setText(QApplication::translate("Widget", "\345\255\246\345\216\206", Q_NULLPTR));
        comboBox_2->clear();
        comboBox_2->insertItems(0, QStringList()
         << QApplication::translate("Widget", "\345\260\217\345\255\246", Q_NULLPTR)
         << QApplication::translate("Widget", "\345\210\235\344\270\255", Q_NULLPTR)
         << QApplication::translate("Widget", "\351\253\230\344\270\255", Q_NULLPTR)
         << QApplication::translate("Widget", "\345\244\247\345\255\246", Q_NULLPTR)
        );
        label_6->setText(QApplication::translate("Widget", "\346\210\267\345\217\243\346\211\200\345\234\250\345\234\260", Q_NULLPTR));
        label_7->setText(QApplication::translate("Widget", "\347\261\215\350\264\257", Q_NULLPTR));
        label_8->setText(QApplication::translate("Widget", "\350\201\224\347\263\273\347\224\265\350\257\235", Q_NULLPTR));
        label_9->setText(QApplication::translate("Widget", "\351\223\266\350\241\214\350\264\246\345\217\267", Q_NULLPTR));
        label_10->setText(QApplication::translate("Widget", "      \347\205\247\347\211\207", Q_NULLPTR));
        dateEdit->setDisplayFormat(QApplication::translate("Widget", "yyyy/M/d", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("Widget", "\345\260\261\350\201\214\344\277\241\346\201\257", Q_NULLPTR));
        label_11->setText(QApplication::translate("Widget", "\345\221\230\345\267\245\347\274\226\345\217\267", Q_NULLPTR));
        label_12->setText(QApplication::translate("Widget", "\351\203\250\351\227\250", Q_NULLPTR));
        comboBox_3->clear();
        comboBox_3->insertItems(0, QStringList()
         << QApplication::translate("Widget", "\350\241\214\346\224\277", Q_NULLPTR)
         << QApplication::translate("Widget", "\350\243\201\346\226\255", Q_NULLPTR)
         << QApplication::translate("Widget", "\351\222\210\350\275\246A", Q_NULLPTR)
         << QApplication::translate("Widget", "\351\222\210\350\275\246B", Q_NULLPTR)
         << QApplication::translate("Widget", "\351\222\210\350\275\246C", Q_NULLPTR)
         << QApplication::translate("Widget", "\351\222\210\350\275\246D", Q_NULLPTR)
         << QApplication::translate("Widget", "\351\222\210\350\275\246E", Q_NULLPTR)
         << QApplication::translate("Widget", "\346\210\220\345\236\213A\345\211\215", Q_NULLPTR)
         << QApplication::translate("Widget", "\346\210\220\345\236\213A\344\270\255", Q_NULLPTR)
         << QApplication::translate("Widget", "\346\210\220\345\236\213A\345\220\216", Q_NULLPTR)
         << QApplication::translate("Widget", "\346\210\220\345\236\213B\345\211\215", Q_NULLPTR)
         << QApplication::translate("Widget", "\346\210\220\345\236\213B\344\270\255", Q_NULLPTR)
         << QApplication::translate("Widget", "\346\210\220\345\236\213B\345\220\216", Q_NULLPTR)
        );
        label_13->setText(QApplication::translate("Widget", "\350\201\214\344\275\215", Q_NULLPTR));
        comboBox_4->clear();
        comboBox_4->insertItems(0, QStringList()
         << QApplication::translate("Widget", "\346\200\273\347\273\217\347\220\206", Q_NULLPTR)
         << QApplication::translate("Widget", "\351\203\250\351\227\250\347\273\217\347\220\206", Q_NULLPTR)
         << QApplication::translate("Widget", "\345\211\257\346\200\273\347\273\217\347\220\206", Q_NULLPTR)
         << QApplication::translate("Widget", "\351\203\250\351\227\250\344\270\273\344\273\273", Q_NULLPTR)
         << QApplication::translate("Widget", "\347\272\277\344\270\212\347\256\241\347\220\206", Q_NULLPTR)
         << QApplication::translate("Widget", "\346\212\200\346\234\257\345\267\245", Q_NULLPTR)
         << QApplication::translate("Widget", "\346\231\256\345\267\245", Q_NULLPTR)
        );
        label_14->setText(QApplication::translate("Widget", "\345\205\245\350\201\214\346\227\245\346\234\237", Q_NULLPTR));
        label_15->setText(QApplication::translate("Widget", "\345\267\245\351\276\204", Q_NULLPTR));
        label_16->setText(QApplication::translate("Widget", "\347\212\266\346\200\201", Q_NULLPTR));
        comboBox_5->clear();
        comboBox_5->insertItems(0, QStringList()
         << QApplication::translate("Widget", "\345\234\250\350\201\214", Q_NULLPTR)
         << QApplication::translate("Widget", "\347\246\273\350\201\214", Q_NULLPTR)
        );
        label_17->setText(QApplication::translate("Widget", "\345\244\207\346\263\250", Q_NULLPTR));
        dateEdit_2->setDisplayFormat(QApplication::translate("Widget", "yyyy/M/d", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Widget", "\346\267\273\345\212\240", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Widget", "\344\277\256\346\224\271", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("Widget", "\346\237\245\350\257\242", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("Widget", "\345\210\240\351\231\244", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("Widget", "\346\270\205\347\251\272", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("Widget", "\351\200\200\345\207\272", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("Widget", "\344\273\216excel\345\257\274\345\205\245", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("Widget", "\345\257\274\345\207\272\345\210\260excel", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("Widget", "\345\244\207\344\273\275json\346\226\207\344\273\266", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
